import { useEffect, useState, type FormEvent } from "react";
import { login } from "@/lib/shop-api";

export function LoginForm({ onSignedIn }: { onSignedIn: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [wifi, setWifi] = useState("");

  useEffect(() => {
    fetch("/api/shop/health")
      .then((r) => r.json())
      .then((d) => {
        const urls = (d.urls || []).filter((u: string) => !u.includes("127.0.0.1") && !u.includes("localhost"));
        if (urls[0]) setWifi(urls[0]);
      })
      .catch(() => {});
  }, []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      await login(username, password);
      onSignedIn();
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : "Could not sign in");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-bg p-6">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-lg border border-line bg-surface p-6">
        <h1 className="text-xl font-semibold text-primary">K F & D Drink Shop</h1>
        <label className="block text-xs text-muted">
          Username
          <input className="field mt-1" autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} />
        </label>
        <label className="block text-xs text-muted">
          Password
          <input
            className="field mt-1"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        {err ? <p className="text-sm text-danger">{err}</p> : null}
        <button type="submit" disabled={busy} className="min-h-11 w-full rounded-md bg-primary font-medium text-primary-fg">
          {busy ? "Signing in…" : "Sign in"}
        </button>
        {wifi ? <p className="text-center text-xs text-muted">{wifi}</p> : null}
      </form>
    </main>
  );
}
