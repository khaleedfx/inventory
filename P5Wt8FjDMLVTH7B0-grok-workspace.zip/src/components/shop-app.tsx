import { useEffect, useMemo, useState } from "react";
import type { Product, Sale, ShopState } from "@/lib/shop-types";
import {
  addStock,
  createStaff,
  getToken,
  listStaff,
  loadMe,
  loadShop,
  logout,
  recordSale,
  restoreShop,
  saveProduct,
  setCount,
  setStaffRole,
  type Staff,
  undoSale,
} from "@/lib/shop-api";
import { naira, todayStr } from "@/lib/utils";
import { LoginForm } from "@/components/login-form";
import {
  LayoutDashboard,
  Package,
  Plus,
  ShoppingCart,
  BookOpen,
  Boxes,
  CalendarDays,
  Printer,
  Users,
} from "lucide-react";

type Tab = "dash" | "stock" | "in" | "sell" | "history" | "products" | "report" | "users";

const ADMIN_TABS: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dash", label: "Dashboard", icon: LayoutDashboard },
  { id: "stock", label: "In the shop", icon: Package },
  { id: "in", label: "Add stock", icon: Plus },
  { id: "sell", label: "Sell", icon: ShoppingCart },
  { id: "history", label: "Sales book", icon: BookOpen },
  { id: "products", label: "Products", icon: Boxes },
  { id: "report", label: "Day report", icon: CalendarDays },
  { id: "users", label: "Staff", icon: Users },
];

const CASHIER_TABS: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "sell", label: "Sell", icon: ShoppingCart },
];

export function ShopApp() {
  const [ready, setReady] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [state, setState] = useState<ShopState | null>(null);
  const [staff, setStaff] = useState<Staff | null>(null);
  const [tab, setTab] = useState<Tab>("sell");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!getToken()) {
      setAuthed(false);
      setReady(true);
      return;
    }
    Promise.all([loadMe(), loadShop()])
      .then(([me, shop]) => {
        setStaff(me);
        setState(shop);
        setAuthed(true);
        setTab(me.role === "admin" ? "dash" : "sell");
      })
      .catch(() => setAuthed(false))
      .finally(() => setReady(true));
  }, []);

  if (!ready) {
    return <div className="grid min-h-screen place-items-center text-muted">Opening shop…</div>;
  }
  if (!authed) return <LoginForm onSignedIn={() => window.location.reload()} />;

  async function run(fn: () => Promise<ShopState>, note = "Saved on this computer") {
    try {
      const next = await fn();
      setState(next);
      setMsg(note);
      setTimeout(() => setMsg(""), 2500);
      return next;
    } catch (e) {
      alert(e instanceof Error ? e.message : "Could not save");
      return null;
    }
  }

  const tabs = staff?.role === "admin" ? ADMIN_TABS : CASHIER_TABS;

  return (
    <div className="mx-auto max-w-6xl px-4 py-5 pb-20">
      <header className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-primary px-5 py-4 text-primary-fg">
        <div>
          <p className="text-lg font-semibold tracking-tight">K F & D Drink Shop</p>
          <p className="text-xs text-primary-fg/70">{staff?.role === "cashier" ? "Cashier" : "Admin"}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="rounded-md bg-primary-fg/10 px-3 py-2 text-sm">
            {staff?.name} · {staff?.role}
          </div>
          <button
            type="button"
            className="rounded-md bg-primary-fg/10 px-3 py-2 text-sm"
            onClick={async () => {
              await logout();
              setAuthed(false);
              setStaff(null);
              setState(null);
            }}
          >
            Sign out
          </button>
        </div>
      </header>
      {msg ? <p className="mt-2 text-sm text-ok">{msg}</p> : null}
      {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}

      <nav className="mt-4 flex flex-wrap gap-2">
        {tabs.map((t) => {
          const Icon = t.icon;
          const on = tab === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`flex min-h-11 items-center gap-2 rounded-full px-4 text-sm font-medium ${
                on ? "bg-primary text-primary-fg" : "bg-surface text-primary"
              }`}
            >
              <Icon className="size-4" />
              {t.label}
            </button>
          );
        })}
      </nav>

      <div className="mt-4">
        {!state ? (
          <p className="text-muted">Opening computer database…</p>
        ) : tab === "dash" && staff?.role === "admin" ? (
          <Dashboard state={state} />
        ) : tab === "stock" && staff?.role === "admin" ? (
          <StockTab state={state} onSet={(id, stock) => run(() => setCount({ productId: id, stock }))} />
        ) : tab === "in" && staff?.role === "admin" ? (
          <InTab state={state} onAdd={(d) => run(() => addStock(d))} />
        ) : tab === "history" && staff?.role === "admin" ? (
          <HistoryTab
            state={state}
            onUndo={(id) => {
              if (confirm("Delete this sale and return the goods to stock?")) run(() => undoSale(id));
            }}
            onBackup={() => {
              const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
              const a = document.createElement("a");
              a.href = URL.createObjectURL(blob);
              a.download = "KFD_shop_database_copy.json";
              a.click();
            }}
            onRestoreClick={() => {
              const input = document.createElement("input");
              input.type = "file";
              input.accept = ".json";
              input.onchange = () => {
                const f = input.files?.[0];
                if (!f) return;
                const reader = new FileReader();
                reader.onload = async () => {
                  try {
                    const payload = JSON.parse(String(reader.result));
                    const next = await restoreShop(payload);
                    setState(next);
                    setMsg("Backup restored");
                    setTimeout(() => setMsg(""), 2500);
                  } catch (e) {
                    alert(e instanceof Error ? e.message : "Invalid backup");
                  }
                };
                reader.readAsText(f);
              };
              input.click();
            }}
          />
        ) : tab === "products" && staff?.role === "admin" ? (
          <ProductsTab state={state} onSave={(d) => run(() => saveProduct(d))} />
        ) : tab === "users" && staff?.role === "admin" ? (
          <UsersTab />
        ) : tab === "report" && staff?.role === "admin" ? (
          <ReportTab state={state} />
        ) : (
          <SellTab
            state={state}
            onSell={async (d) => {
              const next = await run(() => recordSale(d));
              if (!next) throw new Error("Sale not saved");
              return next.sales[0];
            }}
          />
        )}
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-lg border border-line bg-surface p-4">
      <h2 className="mb-3 text-sm font-semibold tracking-wide text-primary">{title}</h2>
      {children}
    </section>
  );
}

function Dashboard({ state }: { state: ShopState }) {
  const t = todayStr();
  const day = state.sales.filter((s) => s.date === t);
  const todayAmt = day.reduce((a, s) => a + s.amount, 0);
  const todayProf = day.reduce((a, s) => a + s.profit, 0);
  const packs = state.products.reduce((a, p) => a + p.stock, 0);
  const stockCost = state.products.reduce((a, p) => a + p.stock * p.cost, 0);
  const allAmt = state.sales.reduce((a, s) => a + s.amount, 0);
  const lows = state.products.filter((p) => p.stock <= p.lowAt);

  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = todayStr(d);
    days.push({
      label: d.toLocaleDateString("en-NG", { weekday: "short" }).slice(0, 2),
      sum: state.sales.filter((s) => s.date === key).reduce((a, s) => a + s.amount, 0),
    });
  }
  const max = Math.max(1, ...days.map((d) => d.sum));

  const pays: Record<string, number> = { Cash: 0, Transfer: 0, POS: 0, Credit: 0 };
  day.forEach((s) => {
    pays[s.pay] = (pays[s.pay] || 0) + s.amount;
  });
  const pmax = Math.max(1, ...Object.values(pays));

  const map: Record<string, number> = {};
  day.forEach((s) =>
    s.items.forEach((i) => {
      map[i.name] = (map[i.name] || 0) + i.qty * i.price;
    }),
  );
  const top = Object.entries(map)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);
  const tmax = Math.max(1, ...top.map((x) => x[1]));

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat dark label="Today sales" value={naira(todayAmt)} sub={day.length + " orders"} />
        <Stat label="Today profit" value={naira(todayProf)} sub="after pack cost" />
        <Stat label="Stock in shop" value={naira(stockCost)} sub={packs + " packs"} />
        <Stat label="All-time sales" value={naira(allAmt)} sub={state.sales.length + " orders"} />
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Card title="LAST 7 DAYS">
          <div className="flex h-36 items-end gap-2">
            {days.map((d) => (
              <div key={d.label} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
                <div className="w-full rounded-sm bg-primary" style={{ height: Math.max(6, Math.round((d.sum / max) * 120)) }} />
                <span className="text-[10px] text-muted">{d.label}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card title="HOW MONEY CAME IN TODAY">
          {Object.entries(pays).map(([k, v]) => (
            <Bar key={k} label={k} value={naira(v)} pct={(v / pmax) * 100} />
          ))}
        </Card>
        <Card title="TOP PRODUCTS TODAY">
          {top.length ? (
            top.map(([n, v]) => <Bar key={n} label={n} value={naira(v)} pct={(v / tmax) * 100} />)
          ) : (
            <p className="text-sm text-muted">No sales today.</p>
          )}
        </Card>
        <Card title="LOW / FINISHED STOCK">
          {lows.length ? (
            lows.map((p) => (
              <div key={p.id} className="flex justify-between border-b border-dashed border-line py-1.5 text-sm">
                <span>{p.name}</span>
                <span className="text-danger">{p.stock} packs</span>
              </div>
            ))
          ) : (
            <p className="text-sm text-muted">None</p>
          )}
          <h2 className="mb-2 mt-4 text-sm font-semibold text-primary">LATEST SALES</h2>
          {state.sales.slice(0, 5).map((s) => (
            <div key={s.id} className="flex justify-between gap-2 border-b border-dashed border-line py-1.5 text-sm">
              <span className="truncate">
                {s.buyer || "Walk-in"} · {s.items.map((i) => i.qty + " " + i.name).join(", ")}
              </span>
              <b className="tabular-nums">{naira(s.amount)}</b>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

function Stat({ label, value, sub, dark }: { label: string; value: string; sub: string; dark?: boolean }) {
  return (
    <div className={`rounded-lg p-4 ${dark ? "bg-primary text-primary-fg" : "border border-line bg-surface"}`}>
      <div className={`text-[11px] uppercase tracking-wide ${dark ? "text-primary-fg/70" : "text-muted"}`}>{label}</div>
      <div className={`mt-1 text-2xl font-semibold tabular-nums ${dark ? "text-primary-fg" : "text-primary"}`}>{value}</div>
      <div className={`mt-1 text-xs ${dark ? "text-primary-fg/70" : "text-muted"}`}>{sub}</div>
    </div>
  );
}

function Bar({ label, value, pct }: { label: string; value: string; pct: number }) {
  return (
    <div className="mb-2 grid grid-cols-[110px_1fr_80px] items-center gap-2 text-sm">
      <span className="truncate">{label}</span>
      <div className="h-2 overflow-hidden rounded-full bg-bg">
        <i className="block h-full rounded-full bg-primary" style={{ width: pct + "%" }} />
      </div>
      <b className="text-right tabular-nums">{value}</b>
    </div>
  );
}

function StockTab({ state, onSet }: { state: ShopState; onSet: (id: string, stock: number) => void }) {
  const packs = state.products.reduce((a, p) => a + p.stock, 0);
  const cost = state.products.reduce((a, p) => a + p.stock * p.cost, 0);
  return (
    <Card title="STOCK">
      <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-4">
        <Stat label="Products" value={String(state.products.length)} sub="" />
        <Stat label="Total packs" value={String(packs)} sub="" />
        <Stat label="Stock at cost" value={naira(cost)} sub="" />
        <Stat label="If sold wholesale" value={naira(state.products.reduce((a, p) => a + p.stock * p.price, 0))} sub="" />
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase text-muted">
              <th className="py-2">Drink</th>
              <th>Pack</th>
              <th className="text-right">In shop</th>
              <th className="text-right">Pieces</th>
              <th className="text-right">Sell / pack</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {state.products.map((p) => (
              <tr key={p.id} className="border-t border-line">
                <td className="py-2 font-medium">{p.name}</td>
                <td>{p.packLabel}</td>
                <td className={`text-right tabular-nums ${p.stock <= p.lowAt ? "text-danger" : ""}`}>{p.stock}</td>
                <td className="text-right tabular-nums">{p.stock * p.packSize}</td>
                <td className="text-right tabular-nums">{naira(p.price)}</td>
                <td className="text-right">
                  <button
                    type="button"
                    className="text-primary"
                    onClick={() => {
                      const raw = prompt("How many packs of " + p.name + " are in the shop now?", String(p.stock));
                      if (raw == null) return;
                      const n = Number(raw);
                      if (Number.isNaN(n) || n < 0) return alert("Enter a number");
                      onSet(p.id, n);
                    }}
                  >
                    Set count
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function InTab({
  state,
  onAdd,
}: {
  state: ShopState;
  onAdd: (d: { productId: string; qty: number; cost: number | null; note: string }) => void;
}) {
  const [productId, setProductId] = useState(state.products[0]?.id || "");
  const [qty, setQty] = useState("");
  const [cost, setCost] = useState("");
  const [note, setNote] = useState("");
  return (
    <Card title="STOCK IN">
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Product">
          <select className="field" value={productId} onChange={(e) => setProductId(e.target.value)}>
            {state.products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name} ({p.stock} in shop)
              </option>
            ))}
          </select>
        </Field>
        <Field label="Packs coming in">
          <input className="field" type="number" min={1} value={qty} onChange={(e) => setQty(e.target.value)} />
        </Field>
        <Field label="Cost per pack this time (optional)">
          <input className="field" type="number" min={0} value={cost} onChange={(e) => setCost(e.target.value)} />
        </Field>
        <Field label="Note">
          <input className="field" value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>
      </div>
      <button
        type="button"
        className="mt-4 min-h-11 w-full rounded-md bg-ok px-4 font-semibold text-primary-fg md:w-60"
        onClick={() => {
          const n = Number(qty);
          if (!productId || n <= 0) return alert("Choose a product and enter packs coming in.");
          onAdd({ productId, qty: n, cost: cost === "" ? null : Number(cost), note });
          setQty("");
          setCost("");
          setNote("");
        }}
      >
        ADD STOCK
      </button>
      <h2 className="mb-2 mt-6 text-sm font-semibold text-primary">STOCK MOVEMENTS</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase text-muted">
              <th className="py-2">When</th>
              <th>Type</th>
              <th>Item</th>
              <th className="text-right">Packs</th>
              <th>Note</th>
            </tr>
          </thead>
          <tbody>
            {state.moves.map((m) => (
              <tr key={m.id} className="border-t border-line">
                <td className="py-2">{new Date(m.at).toLocaleString("en-NG")}</td>
                <td>{m.kind}</td>
                <td>{m.name}</td>
                <td className="text-right tabular-nums">{m.qty > 0 ? "+" + m.qty : m.qty}</td>
                <td>{m.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-xs text-muted">
      {label}
      <div className="mt-1">{children}</div>
    </label>
  );
}

function SellTab({
  state,
  onSell,
}: {
  state: ShopState;
  onSell: (d: {
    buyer: string;
    pay: string;
    note: string;
    date: string;
    items: { id: string; name: string; qty: number; price: number; cost: number; pack: number }[];
  }) => Promise<Sale>;
}) {
  const [cart, setCart] = useState<Record<string, number>>({});
  const [buyer, setBuyer] = useState("");
  const [pay, setPay] = useState("Cash");
  const [note, setNote] = useState("");
  const lines = useMemo(() => {
    return Object.entries(cart)
      .map(([id, qty]) => {
        const p = state.products.find((x) => x.id === id);
        return p && qty > 0 ? { p, qty } : null;
      })
      .filter(Boolean) as { p: Product; qty: number }[];
  }, [cart, state.products]);
  const total = lines.reduce((s, l) => s + l.p.price * l.qty, 0);

  function bump(p: Product, d: number) {
    setCart((c) => {
      const next = { ...c, [p.id]: Math.max(0, (c[p.id] || 0) + d) };
      if (next[p.id] > p.stock) {
        alert("Only " + p.stock + " packs left.");
        next[p.id] = p.stock;
      }
      if (next[p.id] === 0) delete next[p.id];
      return next;
    });
  }

  return (
    <div className="grid gap-3 md:grid-cols-[1.3fr_.9fr]">
      <Card title="PRODUCTS">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {state.products.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => {
                if (p.stock <= 0) return alert(p.name + " is finished in the shop.");
                bump(p, 1);
              }}
              className={`min-h-[96px] rounded-md border border-line bg-bg p-3 text-left ${p.stock <= 0 ? "opacity-40" : ""}`}
            >
              <div className="font-semibold">{p.name}</div>
              <div className="text-xs text-muted">
                {p.packLabel} · {p.packSize} pcs
              </div>
              <div className="mt-1 font-semibold text-primary">{naira(p.price)} / pack</div>
              <div className={`text-xs ${p.stock <= p.lowAt ? "text-danger" : "text-muted"}`}>{p.stock} in shop</div>
            </button>
          ))}
        </div>
      </Card>
      <Card title="ORDER">
        <Field label="Buyer / shop name">
          <input className="field" value={buyer} onChange={(e) => setBuyer(e.target.value)} />
        </Field>
        {lines.length === 0 ? <p className="mt-3 text-sm text-muted">Empty</p> : null}
        {lines.map(({ p, qty }) => (
          <div key={p.id} className="mt-2 flex items-center justify-between border-b border-dashed border-line py-2">
            <div>
              <b>{p.name}</b>
              <div className="text-xs text-muted">{naira(p.price)} per pack</div>
            </div>
            <div className="flex items-center gap-2">
              <button type="button" className="size-8 rounded-sm bg-bg" onClick={() => bump(p, -1)}>
                −
              </button>
              <span className="w-8 text-center tabular-nums">{qty}</span>
              <button type="button" className="size-8 rounded-sm bg-bg" onClick={() => bump(p, 1)}>
                +
              </button>
              <b className="w-20 text-right tabular-nums">{naira(p.price * qty)}</b>
            </div>
          </div>
        ))}
        <div className="mt-3 flex flex-wrap gap-2">
          {["Cash", "Transfer", "POS", "Credit"].map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setPay(m)}
              className={`min-h-10 rounded-md px-3 text-sm ${pay === m ? "bg-primary text-primary-fg" : "bg-bg"}`}
            >
              {m}
            </button>
          ))}
        </div>
        <Field label="Note">
          <input className="field" value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>
        <div className="mt-3 flex items-center justify-between rounded-md bg-primary px-4 py-3 text-primary-fg">
          <span>Order total</span>
          <b className="text-lg tabular-nums">{naira(total)}</b>
        </div>
        <button
          type="button"
          className="mt-3 min-h-12 w-full rounded-md bg-ok px-4 font-semibold text-primary-fg"
          onClick={async () => {
            if (!lines.length) return alert("Add at least one product.");
            try {
              const sale = await onSell({
                buyer,
                pay,
                note,
                date: todayStr(),
                items: lines.map(({ p, qty }) => ({
                  id: p.id,
                  name: p.name,
                  qty,
                  price: p.price,
                  cost: p.cost,
                  pack: p.packSize,
                })),
              });
              setCart({});
              setBuyer("");
              setNote("");
              if (confirm("Sale recorded. Print slip now?")) printSlip(sale);
            } catch (e) {
              alert(e instanceof Error ? e.message : "Could not record sale");
            }
          }}
        >
          RECORD SALE
        </button>
      </Card>
    </div>
  );
}

function HistoryTab({
  state,
  onUndo,
  onBackup,
  onRestoreClick,
}: {
  state: ShopState;
  onUndo: (id: string) => void;
  onBackup: () => void;
  onRestoreClick: () => void;
}) {
  return (
    <Card title="SALES">
      <div className="mb-3 grid grid-cols-3 gap-2">
        <Stat label="Orders" value={String(state.sales.length)} sub="" />
        <Stat label="All money" value={naira(state.sales.reduce((a, s) => a + s.amount, 0))} sub="" />
        <Stat label="All profit" value={naira(state.sales.reduce((a, s) => a + s.profit, 0))} sub="" />
      </div>
      <div className="mb-3 flex flex-wrap gap-2">
        <button type="button" className="min-h-11 rounded-md bg-primary px-4 text-sm font-medium text-primary-fg" onClick={onBackup}>
          Save copy to computer
        </button>
        <button type="button" className="min-h-11 rounded-md border border-line px-4 text-sm" onClick={onRestoreClick}>
          Load copy from computer
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase text-muted">
              <th className="py-2">When</th>
              <th>Cashier</th>
              <th>Buyer</th>
              <th>Items</th>
              <th>Pay</th>
              <th className="text-right">Amount</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {state.sales.map((s) => (
              <tr key={s.id} className="border-t border-line">
                <td className="py-2">{new Date(s.at).toLocaleString("en-NG")}</td>
                <td>{s.cashierName || "—"}</td>
                <td>{s.buyer || "—"}</td>
                <td>{s.items.map((i) => i.qty + " pack " + i.name).join(", ")}</td>
                <td>{s.pay}</td>
                <td className="text-right tabular-nums">{naira(s.amount)}</td>
                <td className="whitespace-nowrap text-right">
                  <button type="button" className="mr-2 text-primary" onClick={() => printSlip(s)}>
                    <Printer className="mr-1 inline size-3" />
                    Print
                  </button>
                  <button type="button" className="text-danger" onClick={() => onUndo(s.id)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function ProductsTab({
  state,
  onSave,
}: {
  state: ShopState;
  onSave: (d: {
    id?: string;
    name: string;
    packLabel: string;
    packSize: number;
    price: number;
    cost: number;
    lowAt: number;
  }) => void;
}) {
  const [editId, setEditId] = useState<string | undefined>();
  const [name, setName] = useState("");
  const [packLabel, setPackLabel] = useState("");
  const [packSize, setPackSize] = useState("12");
  const [price, setPrice] = useState("");
  const [cost, setCost] = useState("");
  const [lowAt, setLowAt] = useState("3");

  function fill(p: Product) {
    setEditId(p.id);
    setName(p.name);
    setPackLabel(p.packLabel);
    setPackSize(String(p.packSize));
    setPrice(String(p.price));
    setCost(String(p.cost));
    setLowAt(String(p.lowAt));
  }

  return (
    <Card title="PRODUCTS">
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Name">
          <input className="field" value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Pack">
          <input className="field" value={packLabel} onChange={(e) => setPackLabel(e.target.value)} />
        </Field>
        <Field label="Pieces in 1 pack">
          <input className="field" type="number" value={packSize} onChange={(e) => setPackSize(e.target.value)} />
        </Field>
        <Field label="Wholesale price per pack">
          <input className="field" type="number" value={price} onChange={(e) => setPrice(e.target.value)} />
        </Field>
        <Field label="Cost per pack">
          <input className="field" type="number" value={cost} onChange={(e) => setCost(e.target.value)} />
        </Field>
        <Field label="Low stock warning">
          <input className="field" type="number" value={lowAt} onChange={(e) => setLowAt(e.target.value)} />
        </Field>
      </div>
      <button
        type="button"
        className="mt-4 min-h-11 rounded-md bg-primary px-5 font-semibold text-primary-fg"
        onClick={() => {
          if (!name || Number(price) <= 0) return alert("Enter name and wholesale price per pack.");
          onSave({
            id: editId,
            name,
            packLabel,
            packSize: Number(packSize) || 1,
            price: Number(price),
            cost: Number(cost) || 0,
            lowAt: Number(lowAt) || 0,
          });
          setEditId(undefined);
          setName("");
          setPackLabel("");
          setPackSize("12");
          setPrice("");
          setCost("");
          setLowAt("3");
        }}
      >
        Save
      </button>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase text-muted">
              <th className="py-2">Drink</th>
              <th>Pack</th>
              <th className="text-right">Pcs</th>
              <th className="text-right">Sell</th>
              <th className="text-right">Cost</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {state.products.map((p) => (
              <tr key={p.id} className="border-t border-line">
                <td className="py-2">{p.name}</td>
                <td>{p.packLabel}</td>
                <td className="text-right">{p.packSize}</td>
                <td className="text-right">{naira(p.price)}</td>
                <td className="text-right">{naira(p.cost)}</td>
                <td className="text-right">
                  <button type="button" className="text-primary" onClick={() => fill(p)}>
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function ReportTab({ state }: { state: ShopState }) {
  const [date, setDate] = useState(todayStr());
  const day = state.sales.filter((s) => s.date === date);
  const map: Record<string, { qty: number; pcs: number; amount: number }> = {};
  day.forEach((s) =>
    s.items.forEach((i) => {
      map[i.name] = map[i.name] || { qty: 0, pcs: 0, amount: 0 };
      map[i.name].qty += i.qty;
      map[i.name].pcs += i.qty * (i.pack || 1);
      map[i.name].amount += i.qty * i.price;
    }),
  );
  const pays: Record<string, number> = {};
  day.forEach((s) => {
    pays[s.pay] = (pays[s.pay] || 0) + s.amount;
  });
  return (
    <Card title="DAY REPORT">
      <Field label="Pick date">
        <input className="field max-w-xs" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </Field>
      <div className="my-3 grid grid-cols-3 gap-2">
        <Stat label="Sales" value={naira(day.reduce((a, s) => a + s.amount, 0))} sub="" />
        <Stat label="Profit" value={naira(day.reduce((a, s) => a + s.profit, 0))} sub="" />
        <Stat label="Orders" value={String(day.length)} sub="" />
      </div>
      <p className="text-sm text-muted">
        {Object.keys(pays).length
          ? Object.entries(pays)
              .map(([k, v]) => k + ": " + naira(v))
              .join("   ·   ")
          : "No sales this day."}
      </p>
      <table className="mt-3 w-full text-sm">
        <thead>
          <tr className="text-left text-[11px] uppercase text-muted">
            <th className="py-2">Drink</th>
            <th className="text-right">Packs</th>
            <th className="text-right">Pieces</th>
            <th className="text-right">Sales</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(map).map(([n, v]) => (
            <tr key={n} className="border-t border-line">
              <td className="py-2">{n}</td>
              <td className="text-right">{v.qty}</td>
              <td className="text-right">{v.pcs}</td>
              <td className="text-right">{naira(v.amount)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  );
}

function UsersTab() {
  const [people, setPeople] = useState<Staff[]>([]);
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"cashier" | "admin">("cashier");

  function refresh() {
    listStaff().then((r) => setPeople(r.people));
  }

  useEffect(() => {
    refresh();
  }, []);

  return (
    <Card title="STAFF">
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="Display name">
          <input className="field" value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Username">
          <input className="field" value={username} onChange={(e) => setUsername(e.target.value)} />
        </Field>
        <Field label="Password">
          <input className="field" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </Field>
        <Field label="Role">
          <select className="field" value={role} onChange={(e) => setRole(e.target.value as "cashier" | "admin")}>
            <option value="cashier">Cashier</option>
            <option value="admin">Admin</option>
          </select>
        </Field>
      </div>
      <button
        type="button"
        className="mt-3 min-h-11 rounded-md bg-primary px-4 font-medium text-primary-fg"
        onClick={async () => {
          if (!username || password.length < 4) return alert("Username and password (4+ characters) required.");
          await createStaff({ username, name: name || username, password, role });
          setUsername("");
          setName("");
          setPassword("");
          refresh();
        }}
      >
        Add staff
      </button>
      <h2 className="mb-2 mt-6 text-sm font-semibold text-primary">ACTIVE</h2>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-[11px] uppercase text-muted">
            <th className="py-2">Name</th>
            <th>Username</th>
            <th>Role</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {people.map((p) => (
            <tr key={p.userId} className="border-t border-line">
              <td className="py-2">{p.name}</td>
              <td>{p.username}</td>
              <td>{p.role}</td>
              <td className="text-right">
                {p.role === "admin" ? (
                  <button type="button" className="text-primary" onClick={() => setStaffRole(p.userId, "cashier").then(refresh)}>
                    Make cashier
                  </button>
                ) : (
                  <button type="button" className="text-primary" onClick={() => setStaffRole(p.userId, "admin").then(refresh)}>
                    Make admin
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  );
}

function printSlip(s?: Sale) {
  if (!s) return;
  const w = window.open("", "slip", "width=360,height=640");
  if (!w) return;
  const rows = s.items
    .map((i) => `<tr><td>${i.qty} pk ${i.name}</td><td style="text-align:right">${naira(i.price * i.qty)}</td></tr>`)
    .join("");
  w.document.write(`<!doctype html><html><body style="font-family:monospace;padding:12px">
    <h1 style="text-align:center;font-size:16px">K F & D DRINK SHOP</h1>
    <p style="text-align:center">Wholesale slip</p>
    <p>Date: ${new Date(s.at).toLocaleString("en-NG")}</p>
    <p>Buyer: ${s.buyer || "—"}</p>
    <p>Pay: ${s.pay}</p>
    <table style="width:100%">${rows}</table>
    <p style="font-weight:800">TOTAL ${naira(s.amount)}</p>
    <p style="text-align:center">Goods sold are not returnable.</p>
    </body></html>`);
  w.document.close();
  w.print();
}
