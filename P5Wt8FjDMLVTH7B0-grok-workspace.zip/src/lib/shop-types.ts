export type Product = {
  id: string;
  name: string;
  packLabel: string;
  packSize: number;
  price: number;
  cost: number;
  stock: number;
  lowAt: number;
};

export type SaleItem = {
  id: string;
  name: string;
  qty: number;
  price: number;
  cost: number;
  pack: number;
};

export type Sale = {
  id: string;
  at: string;
  date: string;
  buyer: string;
  pay: string;
  note: string;
  amount: number;
  profit: number;
  items: SaleItem[];
  cashierId?: string;
  cashierName?: string;
};

export type Move = {
  id: string;
  at: string;
  kind: string;
  productId: string | null;
  name: string;
  qty: number;
  note: string;
};

export type ShopState = {
  products: Product[];
  sales: Sale[];
  moves: Move[];
  source: "database" | "local" | "sqlite";
  dbFile?: string;
};
