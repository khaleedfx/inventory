import type { ShopState } from "@/lib/shop-types";

export type Staff = {
  userId: string;
  username: string;
  name: string;
  role: "admin" | "cashier";
};

const TOKEN_KEY = "kfd_staff_token";

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return sessionStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null) {
  if (typeof window === "undefined") return;
  if (token) sessionStorage.setItem(TOKEN_KEY, token);
  else sessionStorage.removeItem(TOKEN_KEY);
}

async function api(path: string, init?: RequestInit) {
  const headers = new Headers(init?.headers);
  headers.set("Content-Type", "application/json");
  const token = getToken();
  if (token) headers.set("Authorization", "Bearer " + token);
  const r = await fetch("/api/shop" + path, { ...init, headers });
  const data = await r.json().catch(() => ({}));
  if (r.status === 401) {
    setToken(null);
    throw new Error("Unauthorized");
  }
  if (!r.ok) throw new Error(data.error || "Could not talk to the shop database");
  return data;
}

export async function login(username: string, password: string) {
  const data = await api("/login", { method: "POST", body: JSON.stringify({ username, password }) });
  setToken(data.token);
  return data.staff as Staff;
}

export async function logout() {
  try {
    await api("/logout", { method: "POST", body: "{}" });
  } finally {
    setToken(null);
  }
}

export async function loadMe(): Promise<Staff> {
  const data = await api("/me");
  return data.staff as Staff;
}

export async function loadShop(): Promise<ShopState> {
  return (await api("/state")) as ShopState;
}

export async function saveProduct(body: {
  id?: string;
  name: string;
  packLabel: string;
  packSize: number;
  price: number;
  cost: number;
  lowAt: number;
}) {
  return (await api("/product", { method: "POST", body: JSON.stringify(body) })) as ShopState;
}

export async function addStock(body: { productId: string; qty: number; cost: number | null; note: string }) {
  return (await api("/stock", { method: "POST", body: JSON.stringify(body) })) as ShopState;
}

export async function setCount(body: { productId: string; stock: number }) {
  return (await api("/count", { method: "POST", body: JSON.stringify(body) })) as ShopState;
}

export async function recordSale(body: {
  buyer: string;
  pay: string;
  note: string;
  date: string;
  items: { id: string; name: string; qty: number; price: number; cost: number; pack: number }[];
}) {
  return (await api("/sale", { method: "POST", body: JSON.stringify(body) })) as ShopState;
}

export async function undoSale(id: string) {
  return (await api("/undo-sale", { method: "POST", body: JSON.stringify({ id }) })) as ShopState;
}

export async function listStaff() {
  return (await api("/users")) as { people: Staff[]; invites: [] };
}

export async function createStaff(body: { username: string; name: string; password: string; role: "admin" | "cashier" }) {
  return (await api("/users", { method: "POST", body: JSON.stringify(body) })) as { people: Staff[] };
}

export async function setStaffRole(userId: string, role: "admin" | "cashier") {
  return (await api("/users/role", { method: "POST", body: JSON.stringify({ userId, role }) })) as { people: Staff[] };
}

export async function restoreShop(payload: unknown) {
  return (await api("/restore", { method: "POST", body: JSON.stringify(payload) })) as ShopState;
}
