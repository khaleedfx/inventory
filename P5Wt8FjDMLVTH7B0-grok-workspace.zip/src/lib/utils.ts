import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function naira(n: number) {
  return "₦" + Number(n || 0).toLocaleString("en-NG");
}

export function todayStr(d = new Date()) {
  const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return z.toISOString().slice(0, 10);
}

export function uid() {
  return "id" + Date.now().toString(36) + Math.floor(Math.random() * 999).toString(36);
}
