import path from "node:path";
import { defineConfig } from "vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  root: "spa",
  plugins: [tailwindcss(), viteReact()],
  resolve: {
    alias: { "@": path.resolve(__dirname, "src") },
  },
  build: {
    outDir: "../python/static",
    emptyOutDir: true,
    assetsDir: "assets",
  },
});
