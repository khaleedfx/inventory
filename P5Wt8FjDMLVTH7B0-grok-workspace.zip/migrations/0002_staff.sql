create table if not exists shop_staff (
  user_id text primary key,
  email text,
  name text,
  role text not null,
  created_at timestamptz not null default now()
);

create table if not exists shop_invites (
  email text primary key,
  name text,
  role text not null,
  created_at timestamptz not null default now()
);
