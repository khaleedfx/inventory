from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, NamedStyle, Protection
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.formatting.rule import FormulaRule, ColorScaleRule
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import CellIsRule
from openpyxl.workbook.defined_name import DefinedName
from datetime import date

wb = Workbook()

# Colors
NAVY = "1B3A4B"
TEAL = "0D7377"
GOLD = "E8B923"
CREAM = "FFF8E7"
LIGHT = "F4F7F8"
GREEN = "2E8B57"
RED = "C0392B"
WHITE = "FFFFFF"
SOFT_TEAL = "E6F4F1"
SOFT_GOLD = "FFF4D6"

thin = Border(
    left=Side(style='thin', color='D0D5D8'),
    right=Side(style='thin', color='D0D5D8'),
    top=Side(style='thin', color='D0D5D8'),
    bottom=Side(style='thin', color='D0D5D8'),
)
thick_bottom = Border(bottom=Side(style='medium', color=NAVY))

title_font = Font(name='Calibri', size=20, bold=True, color=WHITE)
header_font = Font(name='Calibri', size=11, bold=True, color=WHITE)
section_font = Font(name='Calibri', size=14, bold=True, color=NAVY)
label_font = Font(name='Calibri', size=11, bold=True, color=NAVY)
normal = Font(name='Calibri', size=11, color='1A1A1A')
money_font = Font(name='Calibri', size=11, color='1A1A1A')
input_font = Font(name='Calibri', size=11, color='0000FF')  # blue for inputs

navy_fill = PatternFill('solid', fgColor=NAVY)
teal_fill = PatternFill('solid', fgColor=TEAL)
gold_fill = PatternFill('solid', fgColor=GOLD)
cream_fill = PatternFill('solid', fgColor=CREAM)
light_fill = PatternFill('solid', fgColor=LIGHT)
soft_teal = PatternFill('solid', fgColor=SOFT_TEAL)
soft_gold = PatternFill('solid', fgColor=SOFT_GOLD)
green_fill = PatternFill('solid', fgColor=GREEN)
white_fill = PatternFill('solid', fgColor=WHITE)
yellow_fill = PatternFill('solid', fgColor='FFF3B0')

center = Alignment(horizontal='center', vertical='center', wrap_text=True)
left_align = Alignment(horizontal='left', vertical='center', wrap_text=True)
right_align = Alignment(horizontal='right', vertical='center')

# ===================== PRODUCTS =====================
ws_p = wb.active
ws_p.title = "Products"

ws_p.merge_cells('A1:F1')
ws_p['A1'] = "K F & D DRINK SHOP  ·  PRODUCT LIST"
ws_p['A1'].font = title_font
ws_p['A1'].fill = navy_fill
ws_p['A1'].alignment = center
ws_p.row_dimensions[1].height = 32

ws_p.merge_cells('A2:F2')
ws_p['A2'] = "Edit prices and add new drinks here. Sales sheet will use this list automatically."
ws_p['A2'].font = Font(name='Calibri', size=10, italic=True, color='555555')
ws_p['A2'].fill = cream_fill
ws_p['A2'].alignment = Alignment(horizontal='left', vertical='center')
ws_p.row_dimensions[2].height = 20

headers = ["#", "Product Name", "Size / Pack", "Selling Price (₦)", "Cost Price (₦)", "Active?"]
for col, h in enumerate(headers, 1):
    cell = ws_p.cell(3, col, h)
    cell.font = header_font
    cell.fill = teal_fill
    cell.alignment = center
    cell.border = thin
ws_p.row_dimensions[3].height = 22

# Sample products from shop context
products = [
    (1, "Nutri Milk", "Sachet / Pack", 200, 150, "Yes"),
    (2, "Mr V Water", "75cl", 200, 120, "Yes"),
    (3, "Mr V Water", "1.5L", 300, 180, "Yes"),
    (4, "Eva Water", "75cl", 200, 120, "Yes"),
    (5, "Eva Water", "1.5L", 300, 180, "Yes"),
    (6, "Coca-Cola", "35cl PET", 250, 180, "Yes"),
    (7, "Fanta", "35cl PET", 250, 180, "Yes"),
    (8, "Sprite", "35cl PET", 250, 180, "Yes"),
    (9, "Pepsi", "35cl PET", 250, 180, "Yes"),
    (10, "Maltina", "33cl", 350, 260, "Yes"),
    (11, "Amstel Malta", "33cl", 350, 260, "Yes"),
    (12, "Yoghurt Drink", "Pack", 400, 280, "Yes"),
    (13, "Energy Drink", "Can", 500, 350, "Yes"),
    (14, "Pure Heaven Juice", "Pack", 300, 200, "Yes"),
    (15, "Chi Exotic", "Pack", 350, 240, "Yes"),
]

for i, row in enumerate(products):
    r = 4 + i
    for c, val in enumerate(row, 1):
        cell = ws_p.cell(r, c, val)
        cell.font = input_font if c in (2, 3, 4, 5, 6) else normal
        cell.alignment = center if c != 2 else left_align
        cell.border = thin
        if c in (4, 5):
            cell.number_format = '₦#,##0'
        if i % 2 == 1:
            cell.fill = light_fill
        else:
            cell.fill = white_fill
    ws_p.row_dimensions[r].height = 20

# Extra empty rows for adding products
for i in range(15, 40):
    r = 4 + i
    ws_p.cell(r, 1, i + 1).alignment = center
    ws_p.cell(r, 1).border = thin
    ws_p.cell(r, 1).font = normal
    for c in range(2, 7):
        cell = ws_p.cell(r, c, "")
        cell.font = input_font
        cell.border = thin
        cell.alignment = center if c != 2 else left_align
        if c in (4, 5):
            cell.number_format = '₦#,##0'
        if i % 2 == 1:
            cell.fill = light_fill
    ws_p.cell(r, 6, "Yes")
    ws_p.row_dimensions[r].height = 20

# Data validation for Active
dv_yes = DataValidation(type="list", formula1='"Yes,No"', allow_blank=True)
dv_yes.add('F4:F43')
ws_p.add_data_validation(dv_yes)

ws_p.merge_cells('A45:F46')
ws_p['A45'] = (
    "HOW TO USE: Change prices anytime. To add a new drink, type the name in an empty row. "
    "Keep Active = Yes so it appears in the Sales dropdown. Cost price is optional — used only to show profit."
)
ws_p['A45'].font = Font(name='Calibri', size=10, italic=True, color='444444')
ws_p['A45'].alignment = Alignment(wrap_text=True, vertical='center')
ws_p['A45'].fill = soft_gold

ws_p.column_dimensions['A'].width = 6
ws_p.column_dimensions['B'].width = 28
ws_p.column_dimensions['C'].width = 16
ws_p.column_dimensions['D'].width = 20
ws_p.column_dimensions['E'].width = 18
ws_p.column_dimensions['F'].width = 12
ws_p.freeze_panes = 'A4'
ws_p.sheet_properties.tabColor = TEAL

# Named range for product names (for dropdown)
# We'll use a formula-based list on Sales sheet instead

# ===================== SALES =====================
ws = wb.create_sheet("Sales")

ws.merge_cells('A1:J1')
ws['A1'] = "K F & D DRINK SHOP  ·  SALES BOOK"
ws['A1'].font = title_font
ws['A1'].fill = navy_fill
ws['A1'].alignment = center
ws.row_dimensions[1].height = 34

ws.merge_cells('A2:J2')
ws['A2'] = "Record every sale on a new row. Product list comes from the Products sheet. Date + time help you see busy hours."
ws['A2'].font = Font(name='Calibri', size=10, italic=True, color='555555')
ws['A2'].fill = cream_fill
ws['A2'].alignment = Alignment(horizontal='left', vertical='center')
ws.row_dimensions[2].height = 20

sale_headers = [
    "Date", "Time", "Product", "Qty", "Unit Price (₦)",
    "Amount (₦)", "Cost (₦)", "Profit (₦)", "Payment", "Note"
]
for col, h in enumerate(sale_headers, 1):
    cell = ws.cell(3, col, h)
    cell.font = header_font
    cell.fill = teal_fill
    cell.alignment = center
    cell.border = thin
ws.row_dimensions[3].height = 24

# Pre-fill 200 data rows with formulas
MAX_ROW = 203  # 3 header + 200 sales

# Product dropdown: list from Products!B4:B43
dv_prod = DataValidation(
    type="list",
    formula1="=Products!$B$4:$B$43",
    allow_blank=True,
    showDropDown=False,
)
dv_prod.error = "Pick a product from the list (or add it on Products sheet first)"
dv_prod.errorTitle = "Unknown product"
dv_prod.prompt = "Select drink"
dv_prod.promptTitle = "Product"
dv_prod.add(f'C4:C{MAX_ROW}')
ws.add_data_validation(dv_prod)

dv_pay = DataValidation(type="list", formula1='"Cash,Transfer,POS,Credit"', allow_blank=True)
dv_pay.add(f'I4:I{MAX_ROW}')
ws.add_data_validation(dv_pay)

for r in range(4, MAX_ROW + 1):
    # Date
    c = ws.cell(r, 1)
    c.number_format = 'DD-MMM-YYYY'
    c.font = input_font
    c.alignment = center
    c.border = thin

    # Time
    c = ws.cell(r, 2)
    c.number_format = 'HH:MM'
    c.font = input_font
    c.alignment = center
    c.border = thin

    # Product
    c = ws.cell(r, 3)
    c.font = input_font
    c.alignment = left_align
    c.border = thin

    # Qty
    c = ws.cell(r, 4)
    c.font = input_font
    c.alignment = center
    c.border = thin
    c.number_format = '0'

    # Unit Price — VLOOKUP from Products
    c = ws.cell(r, 5)
    c.value = f'=IF(C{r}="","",IFERROR(VLOOKUP(C{r},Products!$B$4:$E$43,3,FALSE),""))'
    c.font = money_font
    c.alignment = center
    c.border = thin
    c.number_format = '₦#,##0'

    # Amount
    c = ws.cell(r, 6)
    c.value = f'=IF(OR(C{r}="",D{r}=""),"",D{r}*E{r})'
    c.font = Font(name='Calibri', size=11, bold=True, color='1A1A1A')
    c.alignment = center
    c.border = thin
    c.number_format = '₦#,##0'

    # Cost
    c = ws.cell(r, 7)
    c.value = f'=IF(OR(C{r}="",D{r}=""),"",IFERROR(D{r}*VLOOKUP(C{r},Products!$B$4:$E$43,4,FALSE),0))'
    c.font = money_font
    c.alignment = center
    c.border = thin
    c.number_format = '₦#,##0'

    # Profit
    c = ws.cell(r, 8)
    c.value = f'=IF(F{r}="","",F{r}-G{r})'
    c.font = money_font
    c.alignment = center
    c.border = thin
    c.number_format = '₦#,##0'

    # Payment
    c = ws.cell(r, 9)
    c.font = input_font
    c.alignment = center
    c.border = thin

    # Note
    c = ws.cell(r, 10)
    c.font = input_font
    c.alignment = left_align
    c.border = thin

    if (r - 4) % 2 == 1:
        for col in range(1, 11):
            if ws.cell(r, col).fill.fgColor is None or ws.cell(r, col).fill.fgColor.rgb in (None, '00000000'):
                ws.cell(r, col).fill = light_fill

    ws.row_dimensions[r].height = 20

# Sample first sale so they see how it works
ws['A4'] = date(2026, 9, 16)
ws['B4'] = "08:30"
ws['C4'] = "Nutri Milk"
ws['D4'] = 2
ws['I4'] = "Cash"
ws['J4'] = "Opening example — delete or keep"

ws.column_dimensions['A'].width = 14
ws.column_dimensions['B'].width = 9
ws.column_dimensions['C'].width = 24
ws.column_dimensions['D'].width = 8
ws.column_dimensions['E'].width = 16
ws.column_dimensions['F'].width = 14
ws.column_dimensions['G'].width = 12
ws.column_dimensions['H'].width = 12
ws.column_dimensions['I'].width = 12
ws.column_dimensions['J'].width = 28
ws.freeze_panes = 'A4'
ws.auto_filter.ref = f"A3:J{MAX_ROW}"
ws.sheet_properties.tabColor = GOLD

# ===================== DASHBOARD =====================
ws_d = wb.create_sheet("Dashboard", 0)  # first tab

ws_d.merge_cells('A1:G1')
ws_d['A1'] = "K F & D DRINK SHOP  ·  SALES DASHBOARD"
ws_d['A1'].font = title_font
ws_d['A1'].fill = navy_fill
ws_d['A1'].alignment = center
ws_d.row_dimensions[1].height = 36

ws_d.merge_cells('A2:G2')
ws_d['A2'] = "Totals update automatically as you record sales. Set the date filter below to see one day or a period."
ws_d['A2'].font = Font(name='Calibri', size=10, italic=True, color='555555')
ws_d['A2'].fill = cream_fill
ws_d['A2'].alignment = left_align
ws_d.row_dimensions[2].height = 20

# Date filter
ws_d['A4'] = "FROM DATE"
ws_d['A4'].font = label_font
ws_d['A4'].fill = soft_teal
ws_d['A4'].alignment = center
ws_d['B4'] = date(2026, 9, 1)
ws_d['B4'].font = input_font
ws_d['B4'].number_format = 'DD-MMM-YYYY'
ws_d['B4'].fill = yellow_fill
ws_d['B4'].alignment = center
ws_d['B4'].border = thin

ws_d['C4'] = "TO DATE"
ws_d['C4'].font = label_font
ws_d['C4'].fill = soft_teal
ws_d['C4'].alignment = center
ws_d['D4'] = date(2026, 9, 30)
ws_d['D4'].font = input_font
ws_d['D4'].number_format = 'DD-MMM-YYYY'
ws_d['D4'].fill = yellow_fill
ws_d['D4'].alignment = center
ws_d['D4'].border = thin

ws_d.merge_cells('E4:G4')
ws_d['E4'] = "← Change the yellow dates to filter. Leave wide range to see everything."
ws_d['E4'].font = Font(name='Calibri', size=9, italic=True, color='555555')
ws_d['E4'].alignment = left_align

# KPI cards
kpis = [
    (6, "TOTAL SALES (₦)", f'=SUMIFS(Sales!F:F,Sales!A:A,">="&B4,Sales!A:A,"<="&D4)'),
    (7, "TOTAL PROFIT (₦)", f'=SUMIFS(Sales!H:H,Sales!A:A,">="&B4,Sales!A:A,"<="&D4)'),
    (8, "ITEMS SOLD", f'=SUMIFS(Sales!D:D,Sales!A:A,">="&B4,Sales!A:A,"<="&D4)'),
    (9, "NO. OF SALES", f'=COUNTIFS(Sales!A:A,">="&B4,Sales!A:A,"<="&D4,Sales!C:C,"<>")'),
]

ws_d['A6'] = "TOTAL SALES (₦)"
ws_d['A7'] = "TOTAL PROFIT (₦)"
ws_d['A8'] = "ITEMS SOLD"
ws_d['A9'] = "NO. OF SALES"
for r in range(6, 10):
    ws_d.cell(r, 1).font = Font(name='Calibri', size=10, bold=True, color=WHITE)
    ws_d.cell(r, 1).fill = teal_fill
    ws_d.cell(r, 1).alignment = center
    ws_d.cell(r, 1).border = thin

ws_d['B6'] = '=SUMIFS(Sales!F:F,Sales!A:A,">="&$B$4,Sales!A:A,"<="&$D$4)'
ws_d['B7'] = '=SUMIFS(Sales!H:H,Sales!A:A,">="&$B$4,Sales!A:A,"<="&$D$4)'
ws_d['B8'] = '=SUMIFS(Sales!D:D,Sales!A:A,">="&$B$4,Sales!A:A,"<="&$D$4)'
ws_d['B9'] = '=COUNTIFS(Sales!A:A,">="&$B$4,Sales!A:A,"<="&$D$4,Sales!C:C,"<>")'

ws_d['B6'].number_format = '₦#,##0'
ws_d['B7'].number_format = '₦#,##0'
ws_d['B8'].number_format = '#,##0'
ws_d['B9'].number_format = '#,##0'

for r in range(6, 10):
    ws_d.cell(r, 2).font = Font(name='Calibri', size=16, bold=True, color=NAVY)
    ws_d.cell(r, 2).fill = cream_fill
    ws_d.cell(r, 2).alignment = center
    ws_d.cell(r, 2).border = thin
    ws_d.row_dimensions[r].height = 28

# Payment breakdown
ws_d['A11'] = "PAYMENT BREAKDOWN"
ws_d['A11'].font = section_font
ws_d.merge_cells('A11:B11')

ws_d['A12'] = "Cash"
ws_d['A13'] = "Transfer"
ws_d['A14'] = "POS"
ws_d['A15'] = "Credit"
for i, method in enumerate(["Cash", "Transfer", "POS", "Credit"], 12):
    ws_d.cell(i, 1).font = label_font
    ws_d.cell(i, 1).alignment = left_align
    ws_d.cell(i, 1).border = thin
    ws_d.cell(i, 1).fill = soft_teal
    ws_d.cell(i, 2).value = f'=SUMIFS(Sales!F:F,Sales!I:I,A{i},Sales!A:A,">="&$B$4,Sales!A:A,"<="&$D$4)'
    ws_d.cell(i, 2).number_format = '₦#,##0'
    ws_d.cell(i, 2).font = money_font
    ws_d.cell(i, 2).alignment = center
    ws_d.cell(i, 2).border = thin

# Product ranking
ws_d['D11'] = "TOP PRODUCTS (QTY SOLD IN PERIOD)"
ws_d['D11'].font = section_font
ws_d.merge_cells('D11:G11')

ws_d['D12'] = "Product"
ws_d['E12'] = "Qty"
ws_d['F12'] = "Sales (₦)"
ws_d['G12'] = "Profit (₦)"
for col in range(4, 8):
    ws_d.cell(12, col).font = header_font
    ws_d.cell(12, col).fill = navy_fill
    ws_d.cell(12, col).alignment = center
    ws_d.cell(12, col).border = thin

# Pull product names and SUMIF
for i in range(15):
    r = 13 + i
    src = 4 + i
    ws_d.cell(r, 4).value = f'=IF(Products!B{src}="","",Products!B{src})'
    ws_d.cell(r, 4).font = normal
    ws_d.cell(r, 4).alignment = left_align
    ws_d.cell(r, 4).border = thin

    ws_d.cell(r, 5).value = f'=IF(D{r}="","",SUMIFS(Sales!D:D,Sales!C:C,D{r},Sales!A:A,">="&$B$4,Sales!A:A,"<="&$D$4))'
    ws_d.cell(r, 5).number_format = '#,##0'
    ws_d.cell(r, 5).alignment = center
    ws_d.cell(r, 5).border = thin

    ws_d.cell(r, 6).value = f'=IF(D{r}="","",SUMIFS(Sales!F:F,Sales!C:C,D{r},Sales!A:A,">="&$B$4,Sales!A:A,"<="&$D$4))'
    ws_d.cell(r, 6).number_format = '₦#,##0'
    ws_d.cell(r, 6).alignment = center
    ws_d.cell(r, 6).border = thin

    ws_d.cell(r, 7).value = f'=IF(D{r}="","",SUMIFS(Sales!H:H,Sales!C:C,D{r},Sales!A:A,">="&$B$4,Sales!A:A,"<="&$D$4))'
    ws_d.cell(r, 7).number_format = '₦#,##0'
    ws_d.cell(r, 7).alignment = center
    ws_d.cell(r, 7).border = thin

    if i % 2:
        for col in range(4, 8):
            ws_d.cell(r, col).fill = light_fill

# How to use
ws_d.merge_cells('A30:G33')
ws_d['A30'] = (
    "HOW TO USE THIS BOOK\n"
    "1. Products sheet — put every drink you sell and its selling price (and cost if you want profit).\n"
    "2. Sales sheet — each time a customer buys, add one row: Date, Time, pick Product from dropdown, type Qty, pick Cash/Transfer/POS. Price and total fill themselves.\n"
    "3. Dashboard — change the yellow FROM / TO dates to see today's money, this week's money, or the whole month.\n"
    "Works on phone with Microsoft Excel or Google Sheets. Save a copy every week."
)
ws_d['A30'].font = Font(name='Calibri', size=10, color='333333')
ws_d['A30'].alignment = Alignment(wrap_text=True, vertical='top')
ws_d['A30'].fill = soft_gold

ws_d.column_dimensions['A'].width = 22
ws_d.column_dimensions['B'].width = 18
ws_d.column_dimensions['C'].width = 14
ws_d.column_dimensions['D'].width = 24
ws_d.column_dimensions['E'].width = 10
ws_d.column_dimensions['F'].width = 14
ws_d.column_dimensions['G'].width = 14
ws_d.row_dimensions[30].height = 20
ws_d.row_dimensions[31].height = 20
ws_d.row_dimensions[32].height = 20
ws_d.row_dimensions[33].height = 20
ws_d.sheet_properties.tabColor = NAVY
ws_d.freeze_panes = 'A4'

# ===================== TODAY QUICK =====================
ws_t = wb.create_sheet("Today")

ws_t.merge_cells('A1:E1')
ws_t['A1'] = "TODAY'S SALES  ·  QUICK VIEW"
ws_t['A1'].font = title_font
ws_t['A1'].fill = navy_fill
ws_t['A1'].alignment = center
ws_t.row_dimensions[1].height = 32

ws_t.merge_cells('A2:E2')
ws_t['A2'] = "Shows only rows whose Date on the Sales sheet is TODAY (your phone/computer date)."
ws_t['A2'].font = Font(name='Calibri', size=10, italic=True, color='555555')
ws_t['A2'].fill = cream_fill
ws_t.row_dimensions[2].height = 18

ws_t['A4'] = "TODAY"
ws_t['A4'].font = header_font
ws_t['A4'].fill = teal_fill
ws_t['A4'].alignment = center
ws_t['B4'] = '=TODAY()'
ws_t['B4'].number_format = 'DDDD, DD MMMM YYYY'
ws_t['B4'].font = Font(name='Calibri', size=14, bold=True, color=NAVY)
ws_t['B4'].fill = cream_fill
ws_t.merge_cells('B4:E4')

ws_t['A6'] = "Today Sales (₦)"
ws_t['A7'] = "Today Profit (₦)"
ws_t['A8'] = "Today Items"
ws_t['B6'] = '=SUMIF(Sales!A:A,TODAY(),Sales!F:F)'
ws_t['B7'] = '=SUMIF(Sales!A:A,TODAY(),Sales!H:H)'
ws_t['B8'] = '=SUMIF(Sales!A:A,TODAY(),Sales!D:D)'
ws_t['B6'].number_format = '₦#,##0'
ws_t['B7'].number_format = '₦#,##0'
ws_t['B8'].number_format = '#,##0'
for r in range(6, 9):
    ws_t.cell(r, 1).font = Font(name='Calibri', size=11, bold=True, color=WHITE)
    ws_t.cell(r, 1).fill = teal_fill
    ws_t.cell(r, 1).alignment = center
    ws_t.cell(r, 1).border = thin
    ws_t.cell(r, 2).font = Font(name='Calibri', size=16, bold=True, color=NAVY)
    ws_t.cell(r, 2).fill = yellow_fill
    ws_t.cell(r, 2).alignment = center
    ws_t.cell(r, 2).border = thin
    ws_t.row_dimensions[r].height = 26

ws_t['A10'] = "Tip: Record sales on the Sales tab. Come back here anytime to see how much you have made today."
ws_t['A10'].font = Font(name='Calibri', size=10, italic=True, color='444444')
ws_t.merge_cells('A10:E10')

ws_t.column_dimensions['A'].width = 20
ws_t.column_dimensions['B'].width = 18
ws_t.column_dimensions['C'].width = 16
ws_t.column_dimensions['D'].width = 16
ws_t.column_dimensions['E'].width = 16
ws_t.sheet_properties.tabColor = GREEN

# Print setup
for sheet in wb.worksheets:
    sheet.page_setup.orientation = 'landscape'
    sheet.page_setup.fitToPage = True
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    sheet.page_setup.paperSize = sheet.PAPERSIZE_A4
    sheet.sheet_view.showGridLines = False
    sheet.print_title_rows = '1:3'

wb.save('/home/workdir/artifacts/KF_D_Drink_Shop_Sales_Book.xlsx')
print('saved')
