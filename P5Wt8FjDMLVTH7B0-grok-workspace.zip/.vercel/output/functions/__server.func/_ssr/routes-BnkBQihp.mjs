import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, r as QueryClientProvider, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { a as string, i as object, r as number, t as array } from "../_libs/zod.mjs";
import { a as Package, c as CalendarDays, i as Plus, l as Boxes, n as ShoppingCart, o as LayoutDashboard, r as Printer, s as Database, u as BookOpen } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BnkBQihp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var loadShop = createServerFn({ method: "GET" }).handler(createSsrRpc("0c68eebd936b81f1fba98b29c634ee9bf22716ca39eccf9786405ca11033cd48"));
var saveProduct = createServerFn({ method: "POST" }).validator(object({
	id: string().optional(),
	name: string().min(1),
	packLabel: string(),
	packSize: number().int().min(1),
	price: number().int().min(1),
	cost: number().int().min(0),
	lowAt: number().int().min(0)
})).handler(createSsrRpc("f9aa0e966ac6fcd2d42c7908bd9379adef7fabcdd6e066a522961c9d0b15c456"));
var addStock = createServerFn({ method: "POST" }).validator(object({
	productId: string(),
	qty: number().int().min(1),
	cost: number().int().min(0).nullable(),
	note: string()
})).handler(createSsrRpc("1c1c4b6f95b57a1b403aef21e4f46ae5c6cf9b4c8d82e7aefdec143f0e308bb2"));
var setCount = createServerFn({ method: "POST" }).validator(object({
	productId: string(),
	stock: number().int().min(0)
})).handler(createSsrRpc("80de8c7656932cc37c8396e3ac711c062d62da0c294655a5f62334ebb4c8eb83"));
var recordSale = createServerFn({ method: "POST" }).validator(object({
	buyer: string(),
	pay: string(),
	note: string(),
	date: string(),
	items: array(object({
		id: string(),
		name: string(),
		qty: number().int().min(1),
		price: number().int(),
		cost: number().int(),
		pack: number().int()
	}))
})).handler(createSsrRpc("488af73560aac5e8ca623e572617242d911c0cea71622f69b470e96041785605"));
var undoSale = createServerFn({ method: "POST" }).validator(object({ id: string() })).handler(createSsrRpc("e997728feecc936b947e319d91460620f462cdb0ca3487ae1eedb987c8cc026f"));
function naira(n) {
	return "₦" + Number(n || 0).toLocaleString("en-NG");
}
function todayStr(d = /* @__PURE__ */ new Date()) {
	return (/* @__PURE__ */ new Date(d.getTime() - d.getTimezoneOffset() * 6e4)).toISOString().slice(0, 10);
}
var TABS = [
	{
		id: "dash",
		label: "Dashboard",
		icon: LayoutDashboard
	},
	{
		id: "stock",
		label: "In the shop",
		icon: Package
	},
	{
		id: "in",
		label: "Add stock",
		icon: Plus
	},
	{
		id: "sell",
		label: "Sell",
		icon: ShoppingCart
	},
	{
		id: "history",
		label: "Sales book",
		icon: BookOpen
	},
	{
		id: "products",
		label: "Products",
		icon: Boxes
	},
	{
		id: "report",
		label: "Day report",
		icon: CalendarDays
	}
];
function ShopApp() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["shop"],
		queryFn: () => loadShop()
	});
	const state = q.data;
	const [tab, setTab] = (0, import_react.useState)("dash");
	const [msg, setMsg] = (0, import_react.useState)("");
	const mutate = useMutation({
		mutationFn: async (fn) => fn(),
		onSuccess: (data) => {
			qc.setQueryData(["shop"], data);
			setMsg("Saved to database");
			setTimeout(() => setMsg(""), 2500);
		},
		onError: (e) => alert(e.message || "Could not save")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-5 pb-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-center justify-between gap-3 rounded-xl bg-primary px-5 py-4 text-primary-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg font-semibold tracking-tight",
					children: "K F & D Drink Shop"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-primary-fg/70",
					children: "Wholesale stock and sales"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-md bg-primary-fg/10 px-3 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Database, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: state?.source === "database" ? "Saved on server" : q.isLoading ? "Loading…" : "Connecting…" })]
				})]
			}),
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-ok",
				children: msg
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-4 flex flex-wrap gap-2",
				children: TABS.map((t) => {
					const Icon = t.icon;
					const on = tab === t.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab(t.id),
						className: `flex min-h-11 items-center gap-2 rounded-full px-4 text-sm font-medium ${on ? "bg-primary text-primary-fg" : "bg-surface text-primary"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), t.label]
					}, t.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: q.isLoading || !state ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Loading shop…"
				}) : tab === "dash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, { state }) : tab === "stock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StockTab, {
					state,
					onSet: (id, stock) => mutate.mutate(() => setCount({ data: {
						productId: id,
						stock
					} }))
				}) : tab === "in" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InTab, {
					state,
					onAdd: (d) => mutate.mutate(() => addStock({ data: d }))
				}) : tab === "sell" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SellTab, {
					state,
					onSell: (d) => mutate.mutateAsync(() => recordSale({ data: d }))
				}) : tab === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryTab, {
					state,
					onUndo: (id) => {
						if (confirm("Delete this sale and return the goods to stock?")) mutate.mutate(() => undoSale({ data: { id } }));
					}
				}) : tab === "products" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductsTab, {
					state,
					onSave: (d) => mutate.mutate(() => saveProduct({ data: d }))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportTab, { state })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-xs text-muted",
				children: "Data lives in the shop database, not only in this browser. Clearing Edge will not wipe sales."
			})
		]
	});
}
function Card({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-lg border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-sm font-semibold tracking-wide text-primary",
			children: title
		}), children]
	});
}
function Dashboard({ state }) {
	const t = todayStr();
	const day = state.sales.filter((s) => s.date === t);
	const todayAmt = day.reduce((a, s) => a + s.amount, 0);
	const todayProf = day.reduce((a, s) => a + s.profit, 0);
	const packs = state.products.reduce((a, p) => a + p.stock, 0);
	const stockCost = state.products.reduce((a, p) => a + p.stock * p.cost, 0);
	const allAmt = state.sales.reduce((a, s) => a + s.amount, 0);
	const lows = state.products.filter((p) => p.stock <= p.lowAt);
	const days = [];
	for (let i = 6; i >= 0; i--) {
		const d = /* @__PURE__ */ new Date();
		d.setDate(d.getDate() - i);
		const key = todayStr(d);
		days.push({
			label: d.toLocaleDateString("en-NG", { weekday: "short" }).slice(0, 2),
			sum: state.sales.filter((s) => s.date === key).reduce((a, s) => a + s.amount, 0)
		});
	}
	const max = Math.max(1, ...days.map((d) => d.sum));
	const pays = {
		Cash: 0,
		Transfer: 0,
		POS: 0,
		Credit: 0
	};
	day.forEach((s) => {
		pays[s.pay] = (pays[s.pay] || 0) + s.amount;
	});
	const pmax = Math.max(1, ...Object.values(pays));
	const map = {};
	day.forEach((s) => s.items.forEach((i) => {
		map[i.name] = (map[i.name] || 0) + i.qty * i.price;
	}));
	const top = Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 6);
	const tmax = Math.max(1, ...top.map((x) => x[1]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-2 gap-3 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					dark: true,
					label: "Today sales",
					value: naira(todayAmt),
					sub: day.length + " orders"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Today profit",
					value: naira(todayProf),
					sub: "after pack cost"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Stock in shop",
					value: naira(stockCost),
					sub: packs + " packs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "All-time sales",
					value: naira(allAmt),
					sub: state.sales.length + " orders"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					title: "LAST 7 DAYS",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-36 items-end gap-2",
						children: days.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-full flex-1 flex-col items-center justify-end gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full rounded-sm bg-primary",
								style: { height: Math.max(6, Math.round(d.sum / max * 120)) }
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] text-muted",
								children: d.label
							})]
						}, d.label))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					title: "HOW MONEY CAME IN TODAY",
					children: Object.entries(pays).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						label: k,
						value: naira(v),
						pct: v / pmax * 100
					}, k))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					title: "TOP PRODUCTS TODAY",
					children: top.length ? top.map(([n, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						label: n,
						value: naira(v),
						pct: v / tmax * 100
					}, n)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Sell something today to see this."
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					title: "LOW / FINISHED STOCK",
					children: [
						lows.length ? lows.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between border-b border-dashed border-line py-1.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-danger",
								children: [p.stock, " packs"]
							})]
						}, p.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Stock levels look fine."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-2 mt-4 text-sm font-semibold text-primary",
							children: "LATEST SALES"
						}),
						state.sales.slice(0, 5).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-2 border-b border-dashed border-line py-1.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "truncate",
								children: [
									s.buyer || "Walk-in",
									" · ",
									s.items.map((i) => i.qty + " " + i.name).join(", ")
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "tabular-nums",
								children: naira(s.amount)
							})]
						}, s.id))
					]
				})
			]
		})]
	});
}
function Stat({ label, value, sub, dark }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-lg p-4 ${dark ? "bg-primary text-primary-fg" : "border border-line bg-surface"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `text-[11px] uppercase tracking-wide ${dark ? "text-primary-fg/70" : "text-muted"}`,
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-1 text-2xl font-semibold tabular-nums ${dark ? "text-primary-fg" : "text-primary"}`,
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-1 text-xs ${dark ? "text-primary-fg/70" : "text-muted"}`,
				children: sub
			})
		]
	});
}
function Bar({ label, value, pct }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-2 grid grid-cols-[110px_1fr_80px] items-center gap-2 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-2 overflow-hidden rounded-full bg-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
					className: "block h-full rounded-full bg-primary",
					style: { width: pct + "%" }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
				className: "text-right tabular-nums",
				children: value
			})
		]
	});
}
function StockTab({ state, onSet }) {
	const packs = state.products.reduce((a, p) => a + p.stock, 0);
	const cost = state.products.reduce((a, p) => a + p.stock * p.cost, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "EVERYTHING IN THE SHOP NOW",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: "Tap Set count to enter how many packs are physically here."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 grid grid-cols-2 gap-2 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Products",
						value: String(state.products.length),
						sub: ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Total packs",
						value: String(packs),
						sub: ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Stock at cost",
						value: naira(cost),
						sub: ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "If sold wholesale",
						value: naira(state.products.reduce((a, p) => a + p.stock * p.price, 0)),
						sub: ""
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-left text-[11px] uppercase text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2",
								children: "Drink"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Pack" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "In shop"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Pieces"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Sell / pack"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: state.products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 font-medium",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: p.packLabel }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: `text-right tabular-nums ${p.stock <= p.lowAt ? "text-danger" : ""}`,
								children: p.stock
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular-nums",
								children: p.stock * p.packSize
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular-nums",
								children: naira(p.price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-primary",
									onClick: () => {
										const raw = prompt("How many packs of " + p.name + " are in the shop now?", String(p.stock));
										if (raw == null) return;
										const n = Number(raw);
										if (Number.isNaN(n) || n < 0) return alert("Enter a number");
										onSet(p.id, n);
									},
									children: "Set count"
								})
							})
						]
					}, p.id)) })]
				})
			})
		]
	});
}
function InTab({ state, onAdd }) {
	const [productId, setProductId] = (0, import_react.useState)(state.products[0]?.id || "");
	const [qty, setQty] = (0, import_react.useState)("");
	const [cost, setCost] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "ADD STOCK (GOODS ENTERING THE SHOP)",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Product",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field",
							value: productId,
							onChange: (e) => setProductId(e.target.value),
							children: state.products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: p.id,
								children: [
									p.name,
									" (",
									p.stock,
									" in shop)"
								]
							}, p.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Packs coming in",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "number",
							min: 1,
							value: qty,
							onChange: (e) => setQty(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Cost per pack this time (optional)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "number",
							min: 0,
							value: cost,
							onChange: (e) => setCost(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Note",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: note,
							onChange: (e) => setNote(e.target.value),
							placeholder: "Depot"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-4 min-h-11 w-full rounded-md bg-ok px-4 font-semibold text-primary-fg md:w-60",
				onClick: () => {
					const n = Number(qty);
					if (!productId || n <= 0) return alert("Choose a product and enter packs coming in.");
					onAdd({
						productId,
						qty: n,
						cost: cost === "" ? null : Number(cost),
						note
					});
					setQty("");
					setCost("");
					setNote("");
				},
				children: "ADD TO SHOP"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mb-2 mt-6 text-sm font-semibold text-primary",
				children: "STOCK MOVEMENTS"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-left text-[11px] uppercase text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2",
								children: "When"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Type" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Item" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Packs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Note" })
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: state.moves.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2",
								children: new Date(m.at).toLocaleString("en-NG")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: m.kind }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: m.name }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right tabular-nums",
								children: m.qty > 0 ? "+" + m.qty : m.qty
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: m.note })
						]
					}, m.id)) })]
				})
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs text-muted",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1",
			children
		})]
	});
}
function SellTab({ state, onSell }) {
	const [cart, setCart] = (0, import_react.useState)({});
	const [buyer, setBuyer] = (0, import_react.useState)("");
	const [pay, setPay] = (0, import_react.useState)("Cash");
	const [note, setNote] = (0, import_react.useState)("");
	const lines = (0, import_react.useMemo)(() => {
		return Object.entries(cart).map(([id, qty]) => {
			const p = state.products.find((x) => x.id === id);
			return p && qty > 0 ? {
				p,
				qty
			} : null;
		}).filter(Boolean);
	}, [cart, state.products]);
	const total = lines.reduce((s, l) => s + l.p.price * l.qty, 0);
	function bump(p, d) {
		setCart((c) => {
			const next = {
				...c,
				[p.id]: Math.max(0, (c[p.id] || 0) + d)
			};
			if (next[p.id] > p.stock) {
				alert("Only " + p.stock + " packs left.");
				next[p.id] = p.stock;
			}
			if (next[p.id] === 0) delete next[p.id];
			return next;
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 md:grid-cols-[1.3fr_.9fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			title: "TAP TO SELL — QTY = PACKS",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
				children: state.products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						if (p.stock <= 0) return alert(p.name + " is finished in the shop.");
						bump(p, 1);
					},
					className: `min-h-[96px] rounded-md border border-line bg-bg p-3 text-left ${p.stock <= 0 ? "opacity-40" : ""}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-semibold",
							children: p.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted",
							children: [
								p.packLabel,
								" · ",
								p.packSize,
								" pcs"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 font-semibold text-primary",
							children: [naira(p.price), " / pack"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `text-xs ${p.stock <= p.lowAt ? "text-danger" : "text-muted"}`,
							children: [p.stock, " in shop"]
						})
					]
				}, p.id))
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "THIS WHOLESALE ORDER",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Buyer / shop name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: buyer,
						onChange: (e) => setBuyer(e.target.value)
					})
				}),
				lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: "No item yet. Tap a product."
				}) : null,
				lines.map(({ p, qty }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center justify-between border-b border-dashed border-line py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted",
						children: [naira(p.price), " per pack"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "size-8 rounded-sm bg-bg",
								onClick: () => bump(p, -1),
								children: "−"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-8 text-center tabular-nums",
								children: qty
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "size-8 rounded-sm bg-bg",
								onClick: () => bump(p, 1),
								children: "+"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "w-20 text-right tabular-nums",
								children: naira(p.price * qty)
							})
						]
					})]
				}, p.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [
						"Cash",
						"Transfer",
						"POS",
						"Credit"
					].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPay(m),
						className: `min-h-10 rounded-md px-3 text-sm ${pay === m ? "bg-primary text-primary-fg" : "bg-bg"}`,
						children: m
					}, m))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Note",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: note,
						onChange: (e) => setNote(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center justify-between rounded-md bg-primary px-4 py-3 text-primary-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Order total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-lg tabular-nums",
						children: naira(total)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 min-h-12 w-full rounded-md bg-ok px-4 font-semibold text-primary-fg",
					onClick: async () => {
						if (!lines.length) return alert("Add at least one product.");
						const saved = await onSell({
							buyer,
							pay,
							note,
							date: todayStr(),
							items: lines.map(({ p, qty }) => ({
								id: p.id,
								name: p.name,
								qty,
								price: p.price,
								cost: p.cost,
								pack: p.packSize
							}))
						});
						setCart({});
						setBuyer("");
						setNote("");
						if (confirm("Sale recorded. Print slip now?")) printSlip(saved.sales[0]);
					},
					children: "RECORD SALE & REMOVE FROM STOCK"
				})
			]
		})]
	});
}
function HistoryTab({ state, onUndo }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "SALES BOOK",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 grid grid-cols-3 gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Orders",
					value: String(state.sales.length),
					sub: ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "All money",
					value: naira(state.sales.reduce((a, s) => a + s.amount, 0)),
					sub: ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "All profit",
					value: naira(state.sales.reduce((a, s) => a + s.profit, 0)),
					sub: ""
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "text-left text-[11px] uppercase text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2",
							children: "When"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Buyer" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Items" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Pay" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right",
							children: "Amount"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: state.sales.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2",
							children: new Date(s.at).toLocaleString("en-NG")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.buyer || "—" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.items.map((i) => i.qty + " pack " + i.name).join(", ") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.pay }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-right tabular-nums",
							children: naira(s.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "whitespace-nowrap text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "mr-2 text-primary",
								onClick: () => printSlip(s),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "mr-1 inline size-3" }), "Print"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "text-danger",
								onClick: () => onUndo(s.id),
								children: "Delete"
							})]
						})
					]
				}, s.id)) })]
			})
		})]
	});
}
function ProductsTab({ state, onSave }) {
	const [editId, setEditId] = (0, import_react.useState)();
	const [name, setName] = (0, import_react.useState)("");
	const [packLabel, setPackLabel] = (0, import_react.useState)("");
	const [packSize, setPackSize] = (0, import_react.useState)("12");
	const [price, setPrice] = (0, import_react.useState)("");
	const [cost, setCost] = (0, import_react.useState)("");
	const [lowAt, setLowAt] = (0, import_react.useState)("3");
	function fill(p) {
		setEditId(p.id);
		setName(p.name);
		setPackLabel(p.packLabel);
		setPackSize(String(p.packSize));
		setPrice(String(p.price));
		setCost(String(p.cost));
		setLowAt(String(p.lowAt));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "PRODUCT LIST",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: "Add every drink you keep. Opening stock can be 0 — then use Add stock."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Pack description",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							value: packLabel,
							onChange: (e) => setPackLabel(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Pieces in 1 pack",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "number",
							value: packSize,
							onChange: (e) => setPackSize(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Wholesale price per pack",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "number",
							value: price,
							onChange: (e) => setPrice(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Cost per pack",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "number",
							value: cost,
							onChange: (e) => setCost(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Low stock warning",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							type: "number",
							value: lowAt,
							onChange: (e) => setLowAt(e.target.value)
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-4 min-h-11 rounded-md bg-primary px-5 font-semibold text-primary-fg",
				onClick: () => {
					if (!name || Number(price) <= 0) return alert("Enter name and wholesale price per pack.");
					onSave({
						id: editId,
						name,
						packLabel,
						packSize: Number(packSize) || 1,
						price: Number(price),
						cost: Number(cost) || 0,
						lowAt: Number(lowAt) || 0
					});
					setEditId(void 0);
					setName("");
					setPackLabel("");
					setPackSize("12");
					setPrice("");
					setCost("");
					setLowAt("3");
				},
				children: "ADD / SAVE PRODUCT"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "text-left text-[11px] uppercase text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2",
								children: "Drink"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Pack" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Pcs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Sell"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "text-right",
								children: "Cost"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: state.products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: p.packLabel }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right",
								children: p.packSize
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right",
								children: naira(p.price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right",
								children: naira(p.cost)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "text-primary",
									onClick: () => fill(p),
									children: "Edit"
								})
							})
						]
					}, p.id)) })]
				})
			})
		]
	});
}
function ReportTab({ state }) {
	const [date, setDate] = (0, import_react.useState)(todayStr());
	const day = state.sales.filter((s) => s.date === date);
	const map = {};
	day.forEach((s) => s.items.forEach((i) => {
		map[i.name] = map[i.name] || {
			qty: 0,
			pcs: 0,
			amount: 0
		};
		map[i.name].qty += i.qty;
		map[i.name].pcs += i.qty * (i.pack || 1);
		map[i.name].amount += i.qty * i.price;
	}));
	const pays = {};
	day.forEach((s) => {
		pays[s.pay] = (pays[s.pay] || 0) + s.amount;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "DAY REPORT",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Pick date",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field max-w-xs",
					type: "date",
					value: date,
					onChange: (e) => setDate(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "my-3 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Sales",
						value: naira(day.reduce((a, s) => a + s.amount, 0)),
						sub: ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Profit",
						value: naira(day.reduce((a, s) => a + s.profit, 0)),
						sub: ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Orders",
						value: String(day.length),
						sub: ""
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: Object.keys(pays).length ? Object.entries(pays).map(([k, v]) => k + ": " + naira(v)).join("   ·   ") : "No sales this day."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "mt-3 w-full text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "text-left text-[11px] uppercase text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2",
							children: "Drink"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right",
							children: "Packs"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right",
							children: "Pieces"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "text-right",
							children: "Sales"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: Object.entries(map).map(([n, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-t border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2",
							children: n
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-right",
							children: v.qty
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-right",
							children: v.pcs
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-right",
							children: naira(v.amount)
						})
					]
				}, n)) })]
			})
		]
	});
}
function printSlip(s) {
	if (!s) return;
	const w = window.open("", "slip", "width=360,height=640");
	if (!w) return;
	const rows = s.items.map((i) => `<tr><td>${i.qty} pk ${i.name}</td><td style="text-align:right">${naira(i.price * i.qty)}</td></tr>`).join("");
	w.document.write(`<!doctype html><html><body style="font-family:monospace;padding:12px">
    <h1 style="text-align:center;font-size:16px">K F & D DRINK SHOP</h1>
    <p style="text-align:center">Wholesale slip</p>
    <p>Date: ${new Date(s.at).toLocaleString("en-NG")}</p>
    <p>Buyer: ${s.buyer || "—"}</p>
    <p>Pay: ${s.pay}</p>
    <table style="width:100%">${rows}</table>
    <p style="font-weight:800">TOTAL ${naira(s.amount)}</p>
    <p style="text-align:center">Goods sold are not returnable.</p>
    </body></html>`);
	w.document.close();
	w.print();
}
function Home() {
	const [client] = (0, import_react.useState)(() => new QueryClient());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopApp, {})
	});
}
//#endregion
export { Home as component };
