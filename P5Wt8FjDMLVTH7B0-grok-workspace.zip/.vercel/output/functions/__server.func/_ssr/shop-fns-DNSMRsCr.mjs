import { a as string, i as object, r as number, t as array } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop-fns-DNSMRsCr.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var _0002_shop_default = "create table if not exists shop_products (\n  id text primary key,\n  name text not null,\n  pack_label text not null default '',\n  pack_size integer not null default 1,\n  price integer not null default 0,\n  cost integer not null default 0,\n  stock integer not null default 0,\n  low_at integer not null default 3,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists shop_sales (\n  id text primary key,\n  occurred_at timestamptz not null default now(),\n  sale_date date not null,\n  buyer_label text not null default '',\n  pay text not null,\n  note text not null default '',\n  amount integer not null default 0,\n  profit integer not null default 0,\n  items jsonb not null default '[]'::jsonb\n);\n\ncreate index if not exists shop_sales_date_idx on shop_sales (sale_date desc);\n\ncreate table if not exists shop_moves (\n  id text primary key,\n  occurred_at timestamptz not null default now(),\n  kind text not null,\n  product_id text,\n  product_name text not null,\n  qty integer not null,\n  note text not null default ''\n);\n\ncreate index if not exists shop_moves_at_idx on shop_moves (occurred_at desc);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_shop.sql": _0002_shop_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
var SEED = [
	{
		id: "p1",
		name: "Nutri Milk",
		packLabel: "Carton / pack",
		packSize: 24,
		price: 4200,
		cost: 3200,
		lowAt: 3
	},
	{
		id: "p2",
		name: "Mr V Water 75cl",
		packLabel: "Pack of 12",
		packSize: 12,
		price: 2100,
		cost: 1400,
		lowAt: 3
	},
	{
		id: "p3",
		name: "Mr V Water 1.5L",
		packLabel: "Pack of 6",
		packSize: 6,
		price: 1600,
		cost: 1e3,
		lowAt: 3
	},
	{
		id: "p4",
		name: "Eva Water 75cl",
		packLabel: "Pack of 12",
		packSize: 12,
		price: 2100,
		cost: 1400,
		lowAt: 3
	},
	{
		id: "p5",
		name: "Eva Water 1.5L",
		packLabel: "Pack of 6",
		packSize: 6,
		price: 1600,
		cost: 1e3,
		lowAt: 3
	},
	{
		id: "p6",
		name: "Coca-Cola 35cl",
		packLabel: "Pack of 12",
		packSize: 12,
		price: 2700,
		cost: 2e3,
		lowAt: 3
	},
	{
		id: "p7",
		name: "Fanta 35cl",
		packLabel: "Pack of 12",
		packSize: 12,
		price: 2700,
		cost: 2e3,
		lowAt: 3
	},
	{
		id: "p8",
		name: "Sprite 35cl",
		packLabel: "Pack of 12",
		packSize: 12,
		price: 2700,
		cost: 2e3,
		lowAt: 3
	},
	{
		id: "p9",
		name: "Maltina 33cl",
		packLabel: "Pack of 24",
		packSize: 24,
		price: 7800,
		cost: 6e3,
		lowAt: 2
	},
	{
		id: "p10",
		name: "Amstel Malta 33cl",
		packLabel: "Pack of 24",
		packSize: 24,
		price: 7800,
		cost: 6e3,
		lowAt: 2
	},
	{
		id: "p11",
		name: "Yoghurt Drink",
		packLabel: "Pack / carton",
		packSize: 12,
		price: 4200,
		cost: 3e3,
		lowAt: 3
	},
	{
		id: "p12",
		name: "Energy Drink",
		packLabel: "Pack of 24",
		packSize: 24,
		price: 10500,
		cost: 7800,
		lowAt: 2
	}
];
function mapProduct(r) {
	return {
		id: r.id,
		name: r.name,
		packLabel: r.pack_label,
		packSize: Number(r.pack_size),
		price: Number(r.price),
		cost: Number(r.cost),
		stock: Number(r.stock),
		lowAt: Number(r.low_at)
	};
}
function mapSale(r) {
	const items = typeof r.items === "string" ? JSON.parse(r.items) : r.items || [];
	return {
		id: r.id,
		at: String(r.occurred_at),
		date: String(r.sale_date).slice(0, 10),
		buyer: r.buyer_label,
		pay: r.pay,
		note: r.note,
		amount: Number(r.amount),
		profit: Number(r.profit),
		items
	};
}
function mapMove(r) {
	return {
		id: r.id,
		at: String(r.occurred_at),
		kind: r.kind,
		productId: r.product_id,
		name: r.product_name,
		qty: Number(r.qty),
		note: r.note
	};
}
async function readState() {
	const sql = await getSql();
	let products = await sql`
    select id, name, pack_label, pack_size, price, cost, stock, low_at
    from shop_products order by name
  `;
	if (products.length === 0) {
		for (const p of SEED) await sql`
        insert into shop_products (id, name, pack_label, pack_size, price, cost, stock, low_at)
        values (${p.id}, ${p.name}, ${p.packLabel}, ${p.packSize}, ${p.price}, ${p.cost}, ${0}, ${p.lowAt})
      `;
		products = await sql`
      select id, name, pack_label, pack_size, price, cost, stock, low_at
      from shop_products order by name
    `;
	}
	const sales = await sql`
    select id, occurred_at::text, sale_date::text, buyer_label, pay, note, amount, profit, items
    from shop_sales order by occurred_at desc
  `;
	const moves = await sql`
    select id, occurred_at::text, kind, product_id, product_name, qty, note
    from shop_moves order by occurred_at desc limit 80
  `;
	return {
		products: products.map(mapProduct),
		sales: sales.map(mapSale),
		moves: moves.map(mapMove),
		source: "database"
	};
}
var loadShop_createServerFn_handler = createServerRpc({
	id: "0c68eebd936b81f1fba98b29c634ee9bf22716ca39eccf9786405ca11033cd48",
	name: "loadShop",
	filename: "src/lib/shop-fns.ts"
}, (opts) => loadShop.__executeServer(opts));
var loadShop = createServerFn({ method: "GET" }).handler(loadShop_createServerFn_handler, async () => {
	return readState();
});
var saveProduct_createServerFn_handler = createServerRpc({
	id: "f9aa0e966ac6fcd2d42c7908bd9379adef7fabcdd6e066a522961c9d0b15c456",
	name: "saveProduct",
	filename: "src/lib/shop-fns.ts"
}, (opts) => saveProduct.__executeServer(opts));
var saveProduct = createServerFn({ method: "POST" }).validator(object({
	id: string().optional(),
	name: string().min(1),
	packLabel: string(),
	packSize: number().int().min(1),
	price: number().int().min(1),
	cost: number().int().min(0),
	lowAt: number().int().min(0)
})).handler(saveProduct_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const id = data.id || "p" + Date.now().toString(36);
	if (data.id) await sql`
        update shop_products
        set name = ${data.name}, pack_label = ${data.packLabel}, pack_size = ${data.packSize},
            price = ${data.price}, cost = ${data.cost}, low_at = ${data.lowAt}
        where id = ${data.id}
      `;
	else await sql`
        insert into shop_products (id, name, pack_label, pack_size, price, cost, stock, low_at)
        values (${id}, ${data.name}, ${data.packLabel}, ${data.packSize}, ${data.price}, ${data.cost}, ${0}, ${data.lowAt})
      `;
	return readState();
});
var addStock_createServerFn_handler = createServerRpc({
	id: "1c1c4b6f95b57a1b403aef21e4f46ae5c6cf9b4c8d82e7aefdec143f0e308bb2",
	name: "addStock",
	filename: "src/lib/shop-fns.ts"
}, (opts) => addStock.__executeServer(opts));
var addStock = createServerFn({ method: "POST" }).validator(object({
	productId: string(),
	qty: number().int().min(1),
	cost: number().int().min(0).nullable(),
	note: string()
})).handler(addStock_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const p = (await sql`select * from shop_products where id = ${data.productId}`)[0];
	if (!p) throw new Error("Product not found");
	const next = Number(p.stock) + data.qty;
	if (data.cost != null) await sql`update shop_products set stock = ${next}, cost = ${data.cost} where id = ${p.id}`;
	else await sql`update shop_products set stock = ${next} where id = ${p.id}`;
	await sql`
      insert into shop_moves (id, kind, product_id, product_name, qty, note)
      values (${"m" + Date.now().toString(36)}, ${"In"}, ${p.id}, ${p.name}, ${data.qty}, ${data.note || "Stock in"})
    `;
	return readState();
});
var setCount_createServerFn_handler = createServerRpc({
	id: "80de8c7656932cc37c8396e3ac711c062d62da0c294655a5f62334ebb4c8eb83",
	name: "setCount",
	filename: "src/lib/shop-fns.ts"
}, (opts) => setCount.__executeServer(opts));
var setCount = createServerFn({ method: "POST" }).validator(object({
	productId: string(),
	stock: number().int().min(0)
})).handler(setCount_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const p = (await sql`select * from shop_products where id = ${data.productId}`)[0];
	if (!p) throw new Error("Product not found");
	const diff = data.stock - Number(p.stock);
	await sql`update shop_products set stock = ${data.stock} where id = ${p.id}`;
	await sql`
      insert into shop_moves (id, kind, product_id, product_name, qty, note)
      values (${"m" + Date.now().toString(36)}, ${"Count"}, ${p.id}, ${p.name}, ${diff}, ${"Set count to " + data.stock})
    `;
	return readState();
});
var recordSale_createServerFn_handler = createServerRpc({
	id: "488af73560aac5e8ca623e572617242d911c0cea71622f69b470e96041785605",
	name: "recordSale",
	filename: "src/lib/shop-fns.ts"
}, (opts) => recordSale.__executeServer(opts));
var recordSale = createServerFn({ method: "POST" }).validator(object({
	buyer: string(),
	pay: string(),
	note: string(),
	date: string(),
	items: array(object({
		id: string(),
		name: string(),
		qty: number().int().min(1),
		price: number().int(),
		cost: number().int(),
		pack: number().int()
	}))
})).handler(recordSale_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	for (const item of data.items) {
		const p = (await sql`select * from shop_products where id = ${item.id}`)[0];
		if (!p || Number(p.stock) < item.qty) throw new Error("Not enough " + item.name + " in the shop");
	}
	const amount = data.items.reduce((s, i) => s + i.price * i.qty, 0);
	const profit = data.items.reduce((s, i) => s + (i.price - i.cost) * i.qty, 0);
	await sql`
      insert into shop_sales (id, sale_date, buyer_label, pay, note, amount, profit, items)
      values (${"s" + Date.now().toString(36)}, ${data.date}::date, ${data.buyer}, ${data.pay}, ${data.note}, ${amount}, ${profit}, ${JSON.stringify(data.items)}::jsonb)
    `;
	for (const item of data.items) {
		await sql`update shop_products set stock = stock - ${item.qty} where id = ${item.id}`;
		await sql`
        insert into shop_moves (id, kind, product_id, product_name, qty, note)
        values (${"m" + Date.now().toString(36) + item.id.slice(-3)}, ${"Sale"}, ${item.id}, ${item.name}, ${-item.qty}, ${data.buyer || "Sale"})
      `;
	}
	return readState();
});
var undoSale_createServerFn_handler = createServerRpc({
	id: "e997728feecc936b947e319d91460620f462cdb0ca3487ae1eedb987c8cc026f",
	name: "undoSale",
	filename: "src/lib/shop-fns.ts"
}, (opts) => undoSale.__executeServer(opts));
var undoSale = createServerFn({ method: "POST" }).validator(object({ id: string() })).handler(undoSale_createServerFn_handler, async ({ data }) => {
	const sql = await getSql();
	const s = (await sql`select * from shop_sales where id = ${data.id}`)[0];
	if (!s) throw new Error("Sale not found");
	const items = typeof s.items === "string" ? JSON.parse(s.items) : s.items;
	for (const item of items) {
		await sql`update shop_products set stock = stock + ${item.qty} where id = ${item.id}`;
		await sql`
        insert into shop_moves (id, kind, product_id, product_name, qty, note)
        values (${"m" + Date.now().toString(36) + item.id.slice(-3)}, ${"Return"}, ${item.id}, ${item.name}, ${item.qty}, ${"Deleted sale"})
      `;
	}
	await sql`delete from shop_sales where id = ${data.id}`;
	return readState();
});
//#endregion
export { addStock_createServerFn_handler, loadShop_createServerFn_handler, recordSale_createServerFn_handler, saveProduct_createServerFn_handler, setCount_createServerFn_handler, undoSale_createServerFn_handler };
