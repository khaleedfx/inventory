#!/bin/sh
set -eu
cd /workspace
node scripts/preview.mjs stop || true
if [ ! -f python/static/index.html ]; then
  npm run build:shop
fi
python3 - <<'PY' || true
import os, signal
for pid in os.listdir("/proc"):
    if not pid.isdigit():
        continue
    try:
        cmd = open(f"/proc/{pid}/cmdline", "rb").read().replace(b"\x00", b" ").decode()
    except Exception:
        continue
    if "vite dev" in cmd or "with-app-env.mjs vite" in cmd:
        os.kill(int(pid), signal.SIGTERM)
PY
sleep 1
if curl -sf -o /dev/null --max-time 2 http://127.0.0.1:8080/api/shop/health; then
  exit 0
fi
python3 /workspace/python/shop_api.py >>/tmp/shop-api.log 2>&1 &
