@echo off
cd /d "%~dp0"
echo Starting K F and D Drink Shop...
python python\shop_api.py
pause
