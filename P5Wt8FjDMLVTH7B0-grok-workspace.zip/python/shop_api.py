#!/usr/bin/env python3
"""K F & D Drink Shop — local Wi‑Fi software. SQLite + website."""
from __future__ import annotations

import hashlib
import json
import mimetypes
import os
import secrets
import socket
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(ROOT, "data", "kfd_shop.db")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
PORT = int(os.environ.get("KFD_PORT", "8080"))
HOST = "0.0.0.0"

SEED = [
    ("p1", "Nutri Milk", "Carton / pack", 24, 4200, 3200, 3),
    ("p2", "Mr V Water 75cl", "Pack of 12", 12, 2100, 1400, 3),
    ("p3", "Mr V Water 1.5L", "Pack of 6", 6, 1600, 1000, 3),
    ("p4", "Eva Water 75cl", "Pack of 12", 12, 2100, 1400, 3),
    ("p5", "Eva Water 1.5L", "Pack of 6", 6, 1600, 1000, 3),
    ("p6", "Coca-Cola 35cl", "Pack of 12", 12, 2700, 2000, 3),
    ("p7", "Fanta 35cl", "Pack of 12", 12, 2700, 2000, 3),
    ("p8", "Sprite 35cl", "Pack of 12", 12, 2700, 2000, 3),
    ("p9", "Maltina 33cl", "Pack of 24", 24, 7800, 6000, 2),
    ("p10", "Amstel Malta 33cl", "Pack of 24", 24, 7800, 6000, 2),
    ("p11", "Yoghurt Drink", "Pack / carton", 12, 4200, 3000, 3),
    ("p12", "Energy Drink", "Pack of 24", 24, 10500, 7800, 2),
]


def lan_urls(port: int) -> list[str]:
    urls = [f"http://127.0.0.1:{port}"]
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("1.1.1.1", 80))
        ip = sock.getsockname()[0]
        sock.close()
        if ip and not ip.startswith("127."):
            urls.append(f"http://{ip}:{port}")
    except Exception:
        pass
    return urls


def connect():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def hash_pw(password: str, salt: str | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), 120000).hex()
    return salt, digest


def uid(prefix: str) -> str:
    return f"{prefix}{int(time.time() * 1000)}{secrets.token_hex(2)}"


def init_db():
    con = connect()
    con.executescript(
        """
        create table if not exists products (
          id text primary key,
          name text not null,
          pack_label text not null default '',
          pack_size integer not null default 1,
          price integer not null default 0,
          cost integer not null default 0,
          stock integer not null default 0,
          low_at integer not null default 3
        );
        create table if not exists sales (
          id text primary key,
          occurred_at text not null,
          sale_date text not null,
          buyer text not null default '',
          pay text not null,
          note text not null default '',
          amount integer not null default 0,
          profit integer not null default 0,
          items text not null default '[]',
          cashier_id text not null default '',
          cashier_name text not null default ''
        );
        create table if not exists moves (
          id text primary key,
          occurred_at text not null,
          kind text not null,
          product_id text,
          product_name text not null,
          qty integer not null,
          note text not null default ''
        );
        create table if not exists users (
          id text primary key,
          username text not null unique,
          name text not null,
          role text not null,
          salt text not null,
          password_hash text not null
        );
        create table if not exists sessions (
          token text primary key,
          user_id text not null,
          expires_at integer not null
        );
        """
    )
    n = con.execute("select count(*) as c from products").fetchone()["c"]
    if n == 0:
        con.executemany(
            "insert into products (id,name,pack_label,pack_size,price,cost,stock,low_at) values (?,?,?,?,?,?,0,?)",
            SEED,
        )
    cols = [r[1] for r in con.execute("pragma table_info(sales)")]
    if "cashier_id" not in cols:
        con.execute("alter table sales add column cashier_id text not null default ''")
    if "cashier_name" not in cols:
        con.execute("alter table sales add column cashier_name text not null default ''")
    if con.execute("select count(*) as c from users").fetchone()["c"] == 0:
        for username, name, role, password in (
            ("admin", "Shop Admin", "admin", "admin123"),
            ("cashier", "Shop Cashier", "cashier", "cashier123"),
        ):
            salt, digest = hash_pw(password)
            con.execute(
                "insert into users (id,username,name,role,salt,password_hash) values (?,?,?,?,?,?)",
                (uid("u"), username, name, role, salt, digest),
            )
    con.commit()
    con.close()


def user_public(row) -> dict:
    return {
        "userId": row["id"],
        "username": row["username"],
        "name": row["name"],
        "role": row["role"],
        "email": row["username"],
    }


def get_session_user(token: str | None):
    if not token:
        return None
    con = connect()
    row = con.execute(
        "select u.* from sessions s join users u on u.id = s.user_id where s.token=? and s.expires_at > ?",
        (token, int(time.time())),
    ).fetchone()
    con.close()
    return row


def state(staff=None) -> dict:
    con = connect()
    products = [
        {
            "id": r["id"],
            "name": r["name"],
            "packLabel": r["pack_label"],
            "packSize": r["pack_size"],
            "price": r["price"],
            "cost": r["cost"],
            "stock": r["stock"],
            "lowAt": r["low_at"],
        }
        for r in con.execute("select * from products order by name")
    ]
    sales_sql = "select * from sales order by occurred_at desc"
    params: tuple = ()
    if staff is not None and staff["role"] != "admin":
        sales_sql = "select * from sales where cashier_id=? order by occurred_at desc"
        params = (staff["id"],)
    sales = []
    for r in con.execute(sales_sql, params):
        keys = r.keys()
        sales.append(
            {
                "id": r["id"],
                "at": r["occurred_at"],
                "date": r["sale_date"],
                "buyer": r["buyer"],
                "pay": r["pay"],
                "note": r["note"],
                "amount": r["amount"],
                "profit": r["profit"],
                "items": json.loads(r["items"] or "[]"),
                "cashierId": r["cashier_id"] if "cashier_id" in keys else "",
                "cashierName": r["cashier_name"] if "cashier_name" in keys else "",
            }
        )
    moves = []
    if staff is None or staff["role"] == "admin":
        moves = [
            {
                "id": r["id"],
                "at": r["occurred_at"],
                "kind": r["kind"],
                "productId": r["product_id"],
                "name": r["product_name"],
                "qty": r["qty"],
                "note": r["note"],
            }
            for r in con.execute("select * from moves order by occurred_at desc limit 80")
        ]
    con.close()
    return {"products": products, "sales": sales, "moves": moves, "source": "sqlite", "dbFile": "kfd_shop.db"}


def add_move(con, kind, name, qty, note, product_id=None):
    con.execute(
        "insert into moves (id,occurred_at,kind,product_id,product_name,qty,note) values (?,?,?,?,?,?,?)",
        (uid("m"), time.strftime("%Y-%m-%dT%H:%M:%S"), kind, product_id, name, qty, note),
    )


def list_users():
    con = connect()
    people = [user_public(r) for r in con.execute("select * from users order by role, name")]
    con.close()
    return {"people": people, "invites": []}


def handle_post(path: str, data: dict, staff) -> dict:
    if path == "/api/shop/login":
        username = (data.get("username") or "").strip().lower()
        password = data.get("password") or ""
        con = connect()
        row = con.execute("select * from users where lower(username)=?", (username,)).fetchone()
        if not row:
            con.close()
            raise ValueError("Wrong username or password")
        _, digest = hash_pw(password, row["salt"])
        if digest != row["password_hash"]:
            con.close()
            raise ValueError("Wrong username or password")
        token = secrets.token_hex(24)
        con.execute(
            "insert into sessions (token,user_id,expires_at) values (?,?,?)",
            (token, row["id"], int(time.time()) + 60 * 60 * 24 * 30),
        )
        con.commit()
        con.close()
        return {"token": token, "staff": user_public(row)}

    if path == "/api/shop/logout":
        return {"ok": True}

    if staff is None:
        raise PermissionError("Sign in first")

    con = connect()
    try:
        if path == "/api/shop/product":
            if staff["role"] != "admin":
                raise PermissionError("Admin only")
            pid = data.get("id") or uid("p")
            if data.get("id"):
                con.execute(
                    "update products set name=?, pack_label=?, pack_size=?, price=?, cost=?, low_at=? where id=?",
                    (
                        data["name"],
                        data.get("packLabel") or "",
                        int(data.get("packSize") or 1),
                        int(data["price"]),
                        int(data.get("cost") or 0),
                        int(data.get("lowAt") or 3),
                        pid,
                    ),
                )
            else:
                con.execute(
                    "insert into products (id,name,pack_label,pack_size,price,cost,stock,low_at) values (?,?,?,?,?,?,0,?)",
                    (
                        pid,
                        data["name"],
                        data.get("packLabel") or "",
                        int(data.get("packSize") or 1),
                        int(data["price"]),
                        int(data.get("cost") or 0),
                        int(data.get("lowAt") or 3),
                    ),
                )
        elif path == "/api/shop/stock":
            if staff["role"] != "admin":
                raise PermissionError("Admin only")
            p = con.execute("select * from products where id=?", (data["productId"],)).fetchone()
            if not p:
                raise ValueError("Product not found")
            qty = int(data["qty"])
            con.execute("update products set stock = stock + ? where id=?", (qty, p["id"]))
            if data.get("cost") is not None:
                con.execute("update products set cost=? where id=?", (int(data["cost"]), p["id"]))
            add_move(con, "In", p["name"], qty, data.get("note") or "Stock in", p["id"])
        elif path == "/api/shop/count":
            if staff["role"] != "admin":
                raise PermissionError("Admin only")
            p = con.execute("select * from products where id=?", (data["productId"],)).fetchone()
            if not p:
                raise ValueError("Product not found")
            stock = int(data["stock"])
            diff = stock - int(p["stock"])
            con.execute("update products set stock=? where id=?", (stock, p["id"]))
            add_move(con, "Count", p["name"], diff, f"Set count to {stock}", p["id"])
        elif path == "/api/shop/sale":
            items = data["items"]
            for item in items:
                p = con.execute("select * from products where id=?", (item["id"],)).fetchone()
                if not p or int(p["stock"]) < int(item["qty"]):
                    raise ValueError("Not enough " + item["name"] + " in the shop")
            amount = sum(int(i["price"]) * int(i["qty"]) for i in items)
            profit = sum((int(i["price"]) - int(i.get("cost") or 0)) * int(i["qty"]) for i in items)
            sid = uid("s")
            now = time.strftime("%Y-%m-%dT%H:%M:%S")
            con.execute(
                "insert into sales (id,occurred_at,sale_date,buyer,pay,note,amount,profit,items,cashier_id,cashier_name) values (?,?,?,?,?,?,?,?,?,?,?)",
                (
                    sid,
                    now,
                    data.get("date") or time.strftime("%Y-%m-%d"),
                    data.get("buyer") or "",
                    data.get("pay") or "Cash",
                    data.get("note") or "",
                    amount,
                    profit,
                    json.dumps(items),
                    staff["id"],
                    staff["name"],
                ),
            )
            for item in items:
                con.execute("update products set stock = stock - ? where id=?", (int(item["qty"]), item["id"]))
                add_move(con, "Sale", item["name"], -int(item["qty"]), data.get("buyer") or staff["name"], item["id"])
        elif path == "/api/shop/undo-sale":
            if staff["role"] != "admin":
                raise PermissionError("Admin only")
            s = con.execute("select * from sales where id=?", (data["id"],)).fetchone()
            if not s:
                raise ValueError("Sale not found")
            items = json.loads(s["items"] or "[]")
            for item in items:
                con.execute("update products set stock = stock + ? where id=?", (int(item["qty"]), item["id"]))
                add_move(con, "Return", item["name"], int(item["qty"]), "Deleted sale", item["id"])
            con.execute("delete from sales where id=?", (data["id"],))
        elif path == "/api/shop/users":
            if staff["role"] != "admin":
                raise PermissionError("Admin only")
            username = (data.get("username") or "").strip().lower()
            name = (data.get("name") or username).strip()
            role = data.get("role") or "cashier"
            password = data.get("password") or ""
            if not username or len(password) < 4:
                raise ValueError("Enter a username and a password of at least 4 characters")
            if role not in ("admin", "cashier"):
                raise ValueError("Role must be admin or cashier")
            salt, digest = hash_pw(password)
            con.execute(
                "insert into users (id,username,name,role,salt,password_hash) values (?,?,?,?,?,?)",
                (uid("u"), username, name, role, salt, digest),
            )
            con.commit()
            con.close()
            return list_users()
        elif path == "/api/shop/users/role":
            if staff["role"] != "admin":
                raise PermissionError("Admin only")
            role = data.get("role")
            if role not in ("admin", "cashier"):
                raise ValueError("Bad role")
            con.execute("update users set role=? where id=?", (role, data["userId"]))
            con.commit()
            con.close()
            return list_users()
        elif path == "/api/shop/restore":
            if staff["role"] != "admin":
                raise PermissionError("Admin only")
            products = data.get("products")
            if not products:
                raise ValueError("Invalid backup")
            con.execute("delete from moves")
            con.execute("delete from sales")
            con.execute("delete from products")
            for p in products:
                con.execute(
                    "insert into products (id,name,pack_label,pack_size,price,cost,stock,low_at) values (?,?,?,?,?,?,?,?)",
                    (
                        p.get("id") or uid("p"),
                        p["name"],
                        p.get("packLabel") or "",
                        int(p.get("packSize") or 1),
                        int(p.get("price") or 0),
                        int(p.get("cost") or 0),
                        int(p.get("stock") or 0),
                        int(p.get("lowAt") or 0),
                    ),
                )
            for s in data.get("sales") or []:
                con.execute(
                    "insert into sales (id,occurred_at,sale_date,buyer,pay,note,amount,profit,items,cashier_id,cashier_name) values (?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        s.get("id") or uid("s"),
                        s.get("at") or time.strftime("%Y-%m-%dT%H:%M:%S"),
                        s.get("date") or "",
                        s.get("buyer") or "",
                        s.get("pay") or "Cash",
                        s.get("note") or "",
                        int(s.get("amount") or 0),
                        int(s.get("profit") or 0),
                        json.dumps(s.get("items") or []),
                        s.get("cashierId") or "",
                        s.get("cashierName") or "",
                    ),
                )
            for m in data.get("moves") or []:
                con.execute(
                    "insert into moves (id,occurred_at,kind,product_id,product_name,qty,note) values (?,?,?,?,?,?,?)",
                    (
                        m.get("id") or uid("m"),
                        m.get("at") or time.strftime("%Y-%m-%dT%H:%M:%S"),
                        m.get("kind") or "",
                        m.get("productId"),
                        m.get("name") or "",
                        int(m.get("qty") or 0),
                        m.get("note") or "",
                    ),
                )
        else:
            raise ValueError("Unknown path")
        con.commit()
    except sqlite3.IntegrityError:
        con.rollback()
        raise ValueError("That username already exists")
    except Exception:
        con.rollback()
        raise
    finally:
        try:
            con.close()
        except Exception:
            pass
    return state(staff)


MIME = mimetypes.types_map.copy()
MIME.update({".js": "application/javascript", ".mjs": "application/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".json": "application/json", ".woff2": "font/woff2"})


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        print("[shop]", fmt % args)

    def token(self):
        auth = self.headers.get("Authorization") or ""
        if auth.lower().startswith("bearer "):
            return auth[7:].strip()
        return None

    def _send(self, code, payload):
        body = json.dumps(payload).encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def serve_static(self, path: str):
        if path == "/" or path == "" or not os.path.splitext(path)[1]:
            rel = "index.html"
        else:
            rel = path.lstrip("/")
        full = os.path.normpath(os.path.join(STATIC, rel))
        root = os.path.abspath(STATIC)
        if not full.startswith(root):
            self.send_error(403)
            return
        if not os.path.isfile(full):
            embed = os.path.join(os.path.dirname(os.path.abspath(__file__)), "embedded.html")
            if os.path.isfile(embed):
                full = embed
            else:
                full = os.path.join(root, "index.html")
        if not os.path.isfile(full):
            self.send_error(404)
            return
        ext = os.path.splitext(full)[1].lower()
        ctype = MIME.get(ext, "application/octet-stream")
        with open(full, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path in ("/api/shop/health", "/health"):
            self._send(200, {"ok": True, "db": "kfd_shop.db", "offline": True, "urls": lan_urls(PORT)})
            return
        if not path.startswith("/api/shop"):
            self.serve_static(path)
            return
        staff = get_session_user(self.token())
        if staff is None:
            self._send(401, {"error": "Sign in first"})
            return
        if path in ("/api/shop/me",):
            self._send(200, {"staff": user_public(staff)})
            return
        if path in ("/api/shop/state", "/api/shop/backup"):
            self._send(200, state(staff))
            return
        if path == "/api/shop/users":
            if staff["role"] != "admin":
                self._send(403, {"error": "Admin only"})
                return
            self._send(200, list_users())
            return
        self._send(404, {"error": "not found"})

    def do_POST(self):
        path = urlparse(self.path).path
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        staff = get_session_user(self.token())
        try:
            data = json.loads(raw.decode("utf-8") or "{}")
            if path == "/api/shop/logout":
                tok = self.token()
                if tok:
                    con = connect()
                    con.execute("delete from sessions where token=?", (tok,))
                    con.commit()
                    con.close()
                self._send(200, {"ok": True})
                return
            out = handle_post(path, data, staff)
            self._send(200, out)
        except PermissionError as e:
            self._send(403, {"error": str(e)})
        except ValueError as e:
            self._send(400, {"error": str(e)})
        except Exception as e:
            self._send(500, {"error": str(e)})


if __name__ == "__main__":
    init_db()
    os.makedirs(STATIC, exist_ok=True)
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    urls = lan_urls(PORT)
    print("[shop] K F & D Drink Shop", flush=True)
    print("[shop] This computer:", urls[0], flush=True)
    if len(urls) > 1:
        print("[shop] Phones on Wi-Fi:", urls[1], flush=True)
    httpd.serve_forever()
