#!/bin/sh
cd "$(dirname "$0")"
exec python3 python/shop_api.py
